#--===auroraplugin===--
# -*- coding: utf-8 -*-
#  aurora plugin
#  admin_plugin.py
#  edited by kf (kforkingfisher@/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################


def popups_check(gch):
	DBPATH='dynamic/'+gch+'/config.cfg'
	if GCHCFGS[gch].has_key('popups'):
		if GCHCFGS[gch]['popups'] == 1:
			return 1
		else:
			return 0
	else:
		GCHCFGS[gch]['popups']=1
		write_file(DBPATH,str(GCHCFGS[gch]))
		return 1
		
def handler_remote(type, source, parameters):	
	groupchat = source[1]
	nick = source[2]
	
	groupchats = GROUPCHATS.keys()
	groupchats.sort()

	if parameters:
		spltdp = parameters.split(' ', 2)
		dest_gch = spltdp[0]
		
		if len(spltdp) >= 2:
			dest_comm = spltdp[1]
		else:
			reply(type, source, u'Invalid syntax!')
			return
		
		dest_params = ''
		
		if dest_gch.isdigit():
			if int(dest_gch) <= len(groupchats) and int(dest_gch) != 0:
				dest_gch = groupchats[int(dest_gch)-1]
			else:
				reply(type, source, u'The Conference does not exist!')
				return
		else:
			if not dest_gch in groupchats:
				reply(type, source, u'The Conference does not exist!')
				return
				
		if len(spltdp) >= 3:
			dest_params = spltdp[2]
		
		bot_nick = get_bot_nick(dest_gch)
		
		dest_source = [groupchat+'/'+nick,dest_gch,bot_nick]
		
		if COMMAND_HANDLERS.has_key(dest_comm.lower()):
			comm_hnd = COMMAND_HANDLERS[dest_comm.lower()]
		elif MACROS.macrolist[dest_gch].has_key(dest_comm.lower()):
			exp_alias = MACROS.expand(dest_comm.lower(), dest_source)
			
			spl_comm_par = exp_alias.split(' ',1)
			dest_comm = spl_comm_par[0]
			
			if len(spl_comm_par) >= 2:
				alias_par = spl_comm_par[1]
				dest_params = alias_par+' '+dest_params
				dest_params = dest_params.strip()
			
			if COMMAND_HANDLERS.has_key(dest_comm.lower()):
				comm_hnd = COMMAND_HANDLERS[dest_comm.lower()]
			else:
				reply(type, source, u'Unknown command!')
				return
		elif MACROS.gmacrolist.has_key(dest_comm.lower()):
			exp_alias = MACROS.expand(dest_comm.lower(), dest_source)
			
			spl_comm_par = exp_alias.split(' ',1)
			dest_comm = spl_comm_par[0]
			
			if len(spl_comm_par) >= 2:
				alias_par = spl_comm_par[1]
				dest_params = alias_par+' '+dest_params
				dest_params = dest_params.strip()
			
			if COMMAND_HANDLERS.has_key(dest_comm.lower()):
				comm_hnd = COMMAND_HANDLERS[dest_comm.lower()]
			else:
				reply(type, source, u'Unknown command!')
				return
		else:
			reply(type, source, u'Unknown command!')
			return
		
		if type == 'public':
			reply(type, source, u'Look in private!')
			
		comm_hnd('private',dest_source,dest_params)
	else:
		gchli = [u'%s) %s' % (groupchats.index(li)+1,li) for li in groupchats]
		
		if gchli:
			rep = u'Available Conferences:\n%s' % ('\n'.join(gchli))
		else:
			rep = u'No available conferences!'
			
		reply(type, source, rep)

def handler_redirect(type, source, parameters):	
	groupchat = source[1]
	nick = source[2]
	
	if parameters:
		if ':' in parameters:
			spltdp = parameters.split(':', 1)
			dest_nick = spltdp[0]
			
			if len(spltdp) >= 2:
				mess = spltdp[1]
				comm_par = spltdp[1].strip()
				comm_par = comm_par.split(' ',1)
				comm = comm_par[0].strip()
				params = ''
				
				if len(comm_par) >= 2:
					params = comm_par[1].strip()
			else:
				reply(type, source, u'Invalid syntax!')
				return
			
			bot_nick = get_bot_nick(groupchat)
			
			dest_source = [groupchat+'/'+dest_nick,groupchat,bot_nick]
			
			if COMMAND_HANDLERS.has_key(comm.lower()):
				comm_hnd = COMMAND_HANDLERS[comm.lower()]
			elif MACROS.macrolist[groupchat].has_key(comm.lower()):
				exp_alias = MACROS.expand(comm.lower(), dest_source)
				
				spl_comm_par = exp_alias.split(' ',1)
				comm = spl_comm_par[0]
				
				if len(spl_comm_par) >= 2:
					alias_par = spl_comm_par[1]
					params = alias_par+' '+params
					params = params.strip()
				
				if COMMAND_HANDLERS.has_key(comm.lower()):
					comm_hnd = COMMAND_HANDLERS[comm.lower()]
				else:
					reply(type, source, u'Sent!')
					reply('private', [groupchat+'/'+dest_nick,groupchat,dest_nick], mess)
					return
			elif MACROS.gmacrolist.has_key(comm.lower()):
				exp_alias = MACROS.expand(comm.lower(), dest_source)
				
				spl_comm_par = exp_alias.split(' ',1)
				comm = spl_comm_par[0]
				
				if len(spl_comm_par) >= 2:
					alias_par = spl_comm_par[1]
					params = alias_par+' '+params
					params = params.strip()
				
				if COMMAND_HANDLERS.has_key(comm.lower()):
					comm_hnd = COMMAND_HANDLERS[comm.lower()]
				else:
					reply('private', [groupchat+'/'+dest_nick,groupchat,dest_nick], mess)
					reply(type, source, u'Sent!')
					return
			else:
				reply('private', [groupchat+'/'+dest_nick,groupchat,dest_nick], mess)
				reply(type, source, u'Sent!')
				return
			
			comm_hnd('private',dest_source,params)
			reply(type, source, u'Sent!')
		else:
			reply(type, source, u'Invalid syntax!')
	else:
		reply(type, source, u'Invalid syntax!')
				
def handler_admin_join(type, source, parameters):
	if parameters:
		passw = None
		parameters = parameters.split()
		if len(parameters)>1:
			groupchat = parameters[0]+'@conference.nimbuzz.com'
#			passw = string.split(parameters[1], 'pw=', 3)
#			passw = parameters[1].strip('pw=')
			passw = parameters[1]
		else:
			groupchat = parameters[0]+'@conference.nimbuzz.com'
		get_gch_cfg(groupchat)
		for process in STAGE1_INIT:
			with smph:
				INFO['thr'] += 1
				threading.Thread(None,process,'atjoin_init'+str(INFO['thr']),(groupchat,)).start()
		DBPATH='dynamic/'+groupchat+'/config.cfg'
		if GCHCFGS[groupchat].has_key('antikick'):
			pass
		else:
			GCHCFGS[groupchat]['antikick']=1
		write_file(DBPATH, str(GCHCFGS[groupchat]))
		if passw:
			join_groupchat(groupchat, DEFAULT_NICK, passw)
		else:
			join_groupchat(groupchat, DEFAULT_NICK)
		MACROS.load(groupchat)
		reply(type, source, u'join to ' + groupchat)
	else:
		reply(type, source, u'read "help join"')

def handler_admin_leave(type, source, parameters):
	args = parameters.split()
	if len(args)>1:
		groupchat = args[0]+'@conference.nimbuzz.com'
		level=int(user_level(source[1]+'/'+source[2], source[1]))
		if level<40 and groupchat!=source[1]:
			reply(type, source, u'not allowed')
			return
		reason = ' '.join(args[1:]).strip()
		if not GROUPCHATS.has_key(groupchat):
			reply(type, source, u'i am not there')
			return
	elif len(args)==1:
		groupchat = args[0]+'@conference.nimbuzz.com'
		level=int(user_level(source[1]+'/'+source[2], source[1]))
		if level<40 and groupchat!=source[1]:
			reply(type, source, u'not allowed')
			return
		if not GROUPCHATS.has_key(groupchat):
			reply(type, source, u'i am not there')
			return
		reason = ''
	else:
		if not source[1] in GROUPCHATS:
			reply(type, source, u'This command only possible in the conference')
			return
		groupchat = source[1]
		reason = ''
		msg(groupchat, u'Fiamanlillah (a) :)')
	if reason:
		leave_groupchat(groupchat, reason)
	else:
		leave_groupchat(groupchat)
	reply(type, source, u'leaved ' + groupchat)


def handler_admin_msg(type, source, parameters):
	if not parameters:
		reply(type, source, u'read "help message"')
		return
	msg(string.split(parameters)[0], string.join(string.split(parameters)[1:]))
	reply(type, source, u'message sent')
	
def handler_glob_msg_help(type, source, parameters):
	total = '0'
	totalblock='0'
	if GROUPCHATS:
		gch=GROUPCHATS.keys()
		for x in gch:
			if popups_check(x):
				msg(x, u'News from '+source[2]+u':\n'+parameters+u'\nI remind that as usual all a help can be got writing a "help".\nAbout all of bugs, errors, suggestions and structural criticism, please to send me: write ".botadmin <text>", naturally without quotation marks.\nTHANKS FOR YOUR ATTENTION!')
				totalblock = int(totalblock) + 1
			total = int(total) + 1
		reply(type, source, 'message sent to '+str(totalblock)+' conference (from '+str(total)+')')
	else:
		reply(type, source, u'read "help hglobmsg"')
		
def handler_glob_msg(type, source, parameters):
	total = '0'
	totalblock='0'
	if parameters:
		if GROUPCHATS:
			gch=GROUPCHATS.keys()
			for x in gch:
				if popups_check(x):
					msg(x, u'News from '+source[2]+':\n'+parameters)
					totalblock = int(totalblock) + 1
				total = int(total) + 1
			reply(type, source, 'message sent to '+str(totalblock)+' conference (from '+str(total)+')')
	else:
		reply(type, source, u'read "help globmsg"')
	

def handler_admin_s(type, source, parameters):
	if parameters:
		args=parameters.split()[0]
		msg(source[1], parameters)
	else:
		reply(type, source, u'read "help say"')

def handler_admin_restart(type, source, parameters):
	if not source[1] in GROUPCHATS:
		source[2]=source[1].split('@')[0]
	if parameters:
		reason = parameters
	else:
		reason = ''
#	gch=[]
#	if GROUPCHATS:
#		gch=GROUPCHATS.keys()
#	if reason:
#		for x in gch:
#			if popups_check(x):
#				msg(x, u'restarted by '+source[2]+u' reason:\n'+reason)
#	else:
#		for x in gch:
#			if popups_check(x):
#				msg(x, u'restarted by '+source[2])
	prs=xmpp.Presence(typ='unavailable')
#	if reason:
#		prs.setStatus(source[2]+u': restarted me -> '+reason)
#	else:
#		prs.setStatus(source[2]+u': restarted me')
	JCON.send(prs)
	time.sleep(1)
	JCON.disconnect()

def handler_admin_e(type, source, parameters):
	if not source[1] in GROUPCHATS:
		source[2]=source[1].split('@')[0]
	if parameters:
		reason = parameters
	else:
		reason = ''
#	gch=[]
#	if GROUPCHATS:
#		gch=GROUPCHATS.keys()
#	if reason:
#		for x in gch:
#			if popups_check(x):
#				msg(x, u'shut downed by '+source[2]+u' reason:\n'+reason)
#	else:
#		for x in gch:
#			if popups_check(x):
#				msg(x, u'shut downed by '+source[2])
	prs=xmpp.Presence(typ='unavailable')
#	if reason:
#		prs.setStatus(source[2]+u': shut me downed -> '+reason)
#	else:
#		prs.setStatus(source[2]+u': shut me downed')
	JCON.send(prs)
	time.sleep(2)
	os.abort()
	
def handler_popups_onoff(type, source, parameters):
	if not source[1] in GROUPCHATS:
		reply(type, source, u'this command only possible in conference')
		return
	if parameters:
		try:
			parameters=int(parameters.strip())
		except:
			reply(type,source,u'read "help popups"')
			return		
		DBPATH='dynamic/'+source[1]+'/config.cfg'
		if parameters==1:
			GCHCFGS[source[1]]['popups']=1
			reply(type,source,u'global notifications are turned on')
		else:
			GCHCFGS[source[1]]['popups']=0
			reply(type,source,u'global notifications are turned off')
		write_file(DBPATH,str(GCHCFGS[source[1]]))
	else:
		ison=GCHCFGS[source[1]]['popups']
		if ison==1:
			reply(type,source,u'global notifications are turned on here')
		else:
			reply(type,source,u'global notifications are turned off here')


register_command_handler(handler_admin_join, 'join', ['superadmin','muc','all'], 100, 'Join conference, if there is a password write that password right after the name of conference.', 'join <conference> [pw=12345] [reason]', ['join room@conference.server.tld', 'join room@conference.server.tld *VICTORY*', 'join room@conference.server.tld pw=12345 *VICTORY*'])
register_command_handler(handler_admin_leave, 'leave', ['admin','muc','all'], 30, 'Leave conference.', 'leave <conference> [reason]', ['leave room@conference.server.tld sleep', 'leave sleep','leave'])
register_command_handler(handler_admin_msg, 'message', ['admin','muc','all'], 40, 'Send message on behalf of bot to a certain JID.', 'message <jid> <message>', ['message guy@server.tld how are you?'])
register_command_handler(handler_admin_s, 's', ['admin','muc','all'], 20, 'Talk through bot.', 'say <message>', ['say *HI* peoples'])
register_command_handler(handler_admin_restart, 'restart', ['superadmin','all'], 100, 'Restart bot.', 'restart [reason]', ['restart','restart refreshing'])
register_command_handler(handler_admin_e, '.e', ['superadmin','all'], 100, 'Shutdown bot.', 'exit [reason]', ['exit','exit fixing bug'])
register_command_handler(handler_glob_msg, 'globmsg', ['superadmin','muc','all'], 100, 'Send news/message to all conference, where the bot exist.', 'globmsg [message]', ['globmsg hi all!'])
register_command_handler(handler_glob_msg_help, 'hglobmsg', ['superadmin','muc','all'], 100, 'Send news/message to all conference, where the bot exist.', 'globmsg [message]', ['globmsg hi all!'])
register_command_handler(handler_popups_onoff, 'popups', ['admin','muc','all'], 30, 'Off (0) On (1) message about join/leaves, restarts/off, and also global news for certain conf. Without a parameter the bot will based on current status.', 'popups [conf] [1|0]', ['popups room@conference.server.tld 1','popups room@conference.server.tld 0','popups'])
register_command_handler(handler_remote, 'remote', ['superadmin','muc','all','*'], 40, 'Allows you to remotely execute commands and aliases in other conferences on behalf of the bot and get the result. Without parameters displays a list of conferences with the numbers, instead of the full name of the conference can use a number from the list.', 'remote <groupchat|number from the list> <comm> <parameters>', ['remote botzone@conference.jsmart.web.id ping guy','remote 2 time guy','remote'])
register_command_handler(handler_redirect, 'redirect', ['admin','muc','all','*'], 20, 'Redirects the result of a command or an alias to the specified user in private. If the alias or command is not specified and instead the text, or any false, then sends the user a message.', 'redirect <nick>:<command>[<params>]|<mess>', ['redirect guy: ping lady'])
