#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  advertisement_plugin.py
#  coded by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

def advertise_join(groupchat, nick, aff, role):
	DBPATH='dynamic/'+groupchat+'/config.cfg'
	if GROUPCHATS.has_key(groupchat):
		if GCHCFGS[groupchat].has_key('advertise'):
			if GCHCFGS[groupchat].has_key('advertise_msg'):
				if GCHCFGS[groupchat].has_key('advertise_all'):
					pass
				else:
					GCHCFGS[groupchat]['advertise_all'] = 1
					pass
			else:
				GCHCFGS[groupchat]['advertise_msg'] = 'Aurora-Bot By sum0n00001 !\njoin bangladesh-tuna-tuni @ \nattongko@nimbuzz.com'
				if GCHCFGS[groupchat].has_key('advertise_all'):
					pass
				else:
					GCHCFGS[groupchat]['advertise_all'] = 1
					pass
		else:
			GCHCFGS[groupchat]['advertise']=1
			GCHCFGS[groupchat]['advertise_all'] = 1
			GCHCFGS[groupchat]['advertise_msg'] = 'Aurora-Bot By sum0n00001 !\njoin bangladesh-tuna-tuni @ \nattongko@nimbuzz.com'
		write_file(DBPATH,str(GCHCFGS[groupchat]))
		if nick == 'admin':
			return
		elif nick == DEFAULT_NICK:
			return
		else:
			pass
		ad = GCHCFGS[groupchat]['advertise_msg']
		if GCHCFGS[groupchat]['advertise']==1:
			if aff in ('owner', 'admin', 'member'):
				if GCHCFGS[groupchat]['advertise_all'] == 1:
					msg(groupchat+'/'+nick, ad)
			else:
				msg(groupchat+'/'+nick, ad)

def handler_advertise_onoff(type, source, parameters):
	groupchat = source[1]
	if not groupchat in GROUPCHATS:
		reply(type, source, u'This command only possible in the conference')
		return
	DBPATH='dynamic/'+groupchat+'/config.cfg'
	if parameters:
		try:
			parameters=int(parameters.strip())
		except:
			reply(type,source,u'Read "help ad"')
			return
		if parameters==1:
			if GCHCFGS[groupchat]['advertise']==1:
				reply(type,source,u'Advertisement is Already Enabled !')
				return
			else:
				GCHCFGS[groupchat]['advertise']=1
				reply(type,source,u'Advertisement Enabled !')
		elif parameters==0:
			if GCHCFGS[groupchat]['advertise']==0:
				reply(type,source,u'Advertisement is Already Disabled !')
				return
			else:
				GCHCFGS[groupchat]['advertise']=0
				reply(type,source,u'Advertisement Disabled !')
		write_file(DBPATH,str(GCHCFGS[groupchat]))
	else:
		ison=GCHCFGS[groupchat]['advertise']
		if ison==1:
			reply(type,source,u'Advertisement is Enabled here')
		else:
			reply(type,source,u'Advertisement is Disabled here')


def handler_advertise_all_onoff(type, source, parameters):
	groupchat = source[1]
	if not groupchat in GROUPCHATS:
		reply(type, source, u'This command only possible in the conference')
		return
	DBPATH='dynamic/'+groupchat+'/config.cfg'
	if parameters:
		try:
			parameters=int(parameters.strip())
		except:
			reply(type,source,u'Read "help ad_all"')
			return
		if parameters==1:
			if GCHCFGS[groupchat]['advertise_all']==1:
				reply(type,source,u'Advertise-All is Already Enabled !')
				return
			else:
				GCHCFGS[groupchat]['advertise_all']=1
				reply(type,source,u'Advertise-All Enabled !')
		elif parameters==0:
			if GCHCFGS[groupchat]['advertise_all']==0:
				reply(type,source,u'Advertise-All is Already Disabled !')
				return
			else:
				GCHCFGS[groupchat]['advertise_all']=0
				reply(type,source,u'Advertise-All Disabled !')
		write_file(DBPATH,str(GCHCFGS[groupchat]))
	else:
		ison=GCHCFGS[groupchat]['advertise']
		ison_all=GCHCFGS[groupchat]['advertise_all']
		if ison==1:
			if ison_all==1:
				reply(type,source,u'Advertise-All is Enabled here')
			else:
				reply(type,source,u'Advertise-All is Disabled here')
		else:
			reply(type,source,u'Advertisement is Disabled here')

def handler_set_advertisement(type, source, parameters):
	groupchat = source[1]
	if not groupchat in GROUPCHATS:
		reply(type, source, u'This command only possible in the conference')
		return
	DBPATH='dynamic/'+groupchat+'/config.cfg'
	if parameters:
		GCHCFGS[groupchat]['advertise_msg'] = parameters
		write_file(DBPATH,str(GCHCFGS[groupchat]))
		reply(type, source, u'Advertsement set !')
	else:
		current_add = GCHCFGS[groupchat]['advertise_msg']
		reply(type,source,u'Currently Advertising Message : \n'+current_add)

register_join_handler(advertise_join)
register_command_handler(handler_advertise_onoff, 'ad', ['all','amsg','superadmin'], 100, 'on/off advertsiment for all users in particular chatroom. gives current status without parameters (0=off & 1=on)', 'ad <1/0>', ['ad 1','ad 0','ad'])
register_command_handler(handler_advertise_all_onoff, 'ad_all', ['all','amsg','superadmin'], 100, 'on/off advertisement for member,admins & owners ,in particular chatroom. gives current status without parameters (0=off & 1=on) ', 'ad_all <1/0>', ['ad_all 1','ad_all 0','ad_all'])
register_command_handler(handler_set_advertisement, 'ad_set', ['all','amsg','superadmin'], 100, 'Set advertisement message for particular chatroom. shows currently advertising message without parameters.', 'ad_set <message>', ['ad_set join kingfisher','ad_set'])
