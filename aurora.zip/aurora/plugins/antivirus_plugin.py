#--===auroraplugin===--
# -*- coding: utf-8 -*-
#  aurora plugin
#  antivirus_plugin.py
#  Edited by kf (kforkingfisher@/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########

virus = [u'Net-Worm.Win32.Mytob.bd', u'Worm.ExploreZip', u'Trojan.Generic', u'097/Crown.B', u'I-Worm.Mydoom.q', u'Trojan-Dropper.Win32.Microjoin.l', u'Worm.Win32.Feebs.gen_07', u'Win32.HLLM.Graz.00', u'VBS.Redlof.a', u'Joke.Flipped', u'Program.HiddenAdmin.origin', u'I-Worm.Tanatos.a', u'Unknown', u'Jjhfh#j$$^&shdf']
act = [u'[cannot clear !]', u'[cleared !]',u'[Removed !]',u'[Moved to Quarantine !]']
lic = [u'[blacklist]', u'[whitelist]']
scan_status = 0

def handler_test_virus(type, source, parameters):
	global scan_status
	if scan_status == 1:
		reply(type,source,u'abd-protector™ Is Already Scanning Room \nPlease wait....')
		return
	if type == 'public':
		scan_status = 1
		reply(type,source,u'starting abd-protector™ \nPlease wait....')
		time.sleep(random.randrange(0, 6))
		reply(type,source,u'scanning room for viruses...')
		time.sleep(random.randrange(0, 30))
		ocupants = []
		for i in GROUPCHATS[source[1]]:
			if GROUPCHATS[source[1]][i]['ishere'] == 1:
				ocupants.append(i)
		if len(ocupants) > 10:
			count = random.randrange(0, 10)
		else:
			count = random.randrange(0, len(ocupants))
		if count == 0:
			res= u'Room without viruses'
		else:
			res = u'WARNING detected '+str(count)+u' Viruses:'
			for vir in range(0, count):
				oc=random.choice(ocupants)
				vi=random.choice(virus)
				ac=random.choice(act)
				if ac == act[2]:
					order_kick(source[1],oc,u'your virus will remove after your rejoin')
				if ac == act[3]:
					order_visitor(source[1],oc,u'your virus will remove after your rejoin')
				res += '\n'+oc+' ('+vi+') '+ac
		reply(type,source, res)
		scan_status = 0
		return
	elif type == 'private':
		reply(type, source, u'abd-protector™ only works in the conference')

def handler_antivirus_update(type, source, parameters):
        lc=random.choice(lic)
        if lc == lic[1]:
			reply(type,source,u'Connecting to abd-protector™ Update center.....')
			time.sleep(random.randrange(0, 3))
			reply(type,source,u'starting abd-protector™ update...')
			time.sleep(random.randrange(0, 3))
			msg(source[1] ,u'====> 20 %')
			time.sleep(random.randrange(0, 3))
			msg(source[1] ,u'========> 40 %')
			time.sleep(random.randrange(0, 3))
			msg(source[1] ,u'===========> 60 %')
			time.sleep(random.randrange(0, 3))
			msg(source[1] ,u'==============> 80 %')
			time.sleep(random.randrange(0, 3))
			msg(source[1] ,u'================> 100%')
			time.sleep(random.randrange(0, 3))
			msg(source[1] ,u'Update succesfully completed !!')
			return
        if lc == lic[0]:
			reply(type,source,u'Connecting to abd-protector™ Update center...')
			time.sleep(random.randrange(0, 3))
			reply(type,source,u'you have piratated copy of abd-protector™. your key have been banned. please buy licence key.')

register_command_handler(handler_test_virus, 'scan', ['all'], 30, 'Scan room for viruses.', 'scan', ['scan'])
register_command_handler(handler_antivirus_update, 'abd_update', ['all'], 30, 'Update abd-protector™ virus database.', 'abd_update', ['abd_update'])
