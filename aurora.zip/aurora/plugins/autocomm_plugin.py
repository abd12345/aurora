#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  autocomm_plugin.py
#  edited by kf (kforkingfisher@/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

# [[u'????', u'Gigabyte', SOURCE, 1800],[[u'????', u'', SOURCE, 60]],[[u'???', u'Gigabyte', SOURCE, 800]]]

timer_count = 4

import time


def admin_getlistconf(type, source, parameters):
	DBPATH='dynamic/'+source[1]+'/conflist.cfg'
	if check_file(source[1],'conflist.cfg'):
		setup = eval(read_file(DBPATH))
	try:
		set_nomer = setup['nomer']
	except:
		setup['nomer'] = '1'
		set_nomer = setup['nomer']
#*******************************************
	try:
		set_conf = setup['conf']
	except:
		setup['conf'] = '1'
		set_conf = setup['conf']
#*******************************************
	try:
		set_botnick = setup['botnick']
	except:
		setup['botnick'] = '1'
		set_botnick = setup['botnick']
#*******************************************
	try:
		set_allusers = setup['allusers']
	except:
		setup['allusers'] = '1'
		set_allusers = setup['allusers']
#*******************************************
	try:
		set_redusers = setup['redusers']
	except:
		setup['redusers'] = '1'
		set_redusers = setup['redusers']
#*******************************************
	try:
		set_yellusers = setup['yellusers']
	except:
		setup['yellusers'] = '1'
		set_yellusers = setup['yellusers']
#*******************************************
	try:
		set_botstatus = setup['botstatus']
	except:
		setup['botstatus'] = '1'
		set_botstatus = setup['botstatus']
#*******************************************
	try:
		set_botadmin = setup['botadmin']
	except:
		setup['botadmin'] = '1'
		set_botadmin = setup['botadmin']
	write_file(DBPATH, str(setup))
#*******************************************
	try:
		set_serverdef = setup['serverdef']
	except:
		setup['serverdef'] = 'jsmart.web.id'
		set_serverdef = setup['serverdef']
	write_file(DBPATH, str(setup))
#*******************************************
	try:
		set_shortserver = setup['shortserver']
	except:
		setup['shortserver'] = '1'
		set_shortserver = setup['shortserver']
	write_file(DBPATH, str(setup))


	if parameters != '':
		command = parameters.split()
		if (len(command) == 1) & (command[0] == u'find'):
			reply(type, source, u'what should i find?')
			return
		if (len(command) == 1) & (command[0] == u'option'):
			reply(type, source, u'Customize the list of display information in a conferences, command option:\n * number\n * conf\n * botnick\n * allusers\n * redusers\n * yellusers\n * botstatus\n * botadmin\n ** shortserver\n ** servdef\n *** find - search for combinations of letters in the conference')
			return
		allkeys = [u'number', u'conf', u'botnick', u'allusers', u'redusers', u'yellusers', u'botstatus', u'botadmin', u'shortserver', u'servdef'] 
		if (len(command) == 2) & (command[0] == u'option'):
			if not command[1] in allkeys:
				reply(type, source, u'invalid option')
				return
			if command[1] == u'number':
				if setup['nomer'] == '1':
					res = u'enabled'
				if setup['nomer'] == '0':
					res = u'disabled'
			if command[1] == u'conf':
				if setup['conf'] == '1':
					res = u'enabled'
				if setup['conf'] == '0':
					res = u'disabled'
			if command[1] == u'botnick':
				if setup['botnick'] == '1':
					res = u'enabled'
				if setup['botnick'] == '0':
					res = u'disabled'
			if command[1] == u'allusers':
				if setup['allusers'] == '1':
					res = u'enabled'
				if setup['allusers'] == '0':
					res = u'disabled'
			if command[1] == u'redusers':
				if setup['redusers'] == '1':
					res = u'enabled'
				if setup['redusers'] == '0':
					res = u'disabled'
			if command[1] == u'yellusers':
				if setup['yellusers'] == '1':
					res = u'enabled'
				if setup['yellusers'] == '0':
					res = u'disabled'
			if command[1] == u'botstatus':
				if setup['botstatus'] == '1':
					res = u'enabled'
				if setup['botstatus'] == '0':
					res = u'disabled'
			if command[1] == u'botadmin':
				if setup['botadmin'] == '1':
					res = u'enabled'
				if setup['botadmin'] == '0':
					res = u'disabled'
			if command[1] == u'shortserver':
				if setup['shortserver'] == '1':
					res = u'enabled'
				if setup['shortserver'] == '0':
					res = u'disabled'
			if command[1] == u'serverdef':
				res = setup['serverdef']


			reply(type, source, u'option '+command[1]+u' are available: '+res)
			return
		if (len(command) == 3) & (command[0] == u'option'):
			if not command[1] in allkeys:
				reply(type, source, u'invalid option')
				return

			if command[1] == u'number':
				if (command[2] == '1') | (command[2] == '0'):
					set_nomer = command[2]
					setup['nomer'] = command[2]
					write_file(DBPATH, str(setup))
					if command[2] == '1':
						res = u'enabled'
					if command[2] == '0':
						res = u'disabled'
					reply(type, source, u'display number '+res)
			if command[1] == u'conf':
				if (command[2] == '1') | (command[2] == '0'):
					set_conf = command[2]
					setup['conf'] = command[2]
					write_file(DBPATH, str(setup))
					if command[2] == '1':
						res = u'enabled'
					if command[2] == '0':
						res = u'disabled'
					reply(type, source, u'display conf '+res)
			if command[1] == u'botnick':
				if (command[2] == '1') | (command[2] == '0'):
					set_botnick = command[2]
					setup['botnick'] = command[2]
					write_file(DBPATH, str(setup))
					if command[2] == '1':
						res = u'enabled'
					if command[2] == '0':
						res = u'disabled'
					reply(type, source, u'display botnick '+res)
			if command[1] == u'allusers':
				if (command[2] == '1') | (command[2] == '0'):
					set_allusers = command[2]
					setup['allusers'] = command[2]
					write_file(DBPATH, str(setup))
					if command[2] == '1':
						res = u'enabled'
					if command[2] == '0':
						res = u'disabled'
					reply(type, source, u'display allusers '+res)
			if command[1] == u'redusers':
				if (command[2] == '1') | (command[2] == '0'):
					set_redusers = command[2]
					setup['redusers'] = command[2]
					write_file(DBPATH, str(setup))
					if command[2] == '1':
						res = u'enabled'
					if command[2] == '0':
						res = u'disabled'
					reply(type, source, u'display moderators '+res)
			if command[1] == u'yellusers':
				if (command[2] == '1') | (command[2] == '0'):
					set_yellusers = command[2]
					setup['yellusers'] = command[2]
					write_file(DBPATH, str(setup))
					if command[2] == '1':
						res = u'enabled'
					if command[2] == '0':
						res = u'disabled'
					reply(type, source, u'display member/participants '+res)
			if command[1] == u'botstatus':
				if (command[2] == '1') | (command[2] == '0'):
					set_botstatus = command[2]
					setup['botstatus'] = command[2]
					write_file(DBPATH, str(setup))
					if command[2] == '1':
						res = u'enabled'
					if command[2] == '0':
						res = u'disabled'
					reply(type, source, u'display role of bot '+res)
			if command[1] == u'botadmin':
				if (command[2] == '1') | (command[2] == '0'):
					set_botadmin = command[2]
					setup['botadmin'] = command[2]
					write_file(DBPATH, str(setup))
					if command[2] == '1':
						res = u'enabled'
					if command[2] == '0':
						res = u'disabled'
					reply(type, source, u'display botadmin '+res)
			if command[1] == u'shortserver':
				if (command[2] == '1') | (command[2] == '0'):
					set_shortserver = command[2]
					setup['shortserver'] = command[2]
					write_file(DBPATH, str(setup))
					if command[2] == '1':
						res = u'enabled'
					if command[2] == '0':
						res = u'disabled'
					reply(type, source, u'use short server '+res)
			if command[1] == u'serverdef':
				if (command[2].count('.') > 0):
					set_serverdef = command[2]
					setup['serverdef'] = command[2]
					write_file(DBPATH, str(setup))
					res = command[2]
					reply(type, source, u'set default server: '+res)
			return
#********************************************************
#	if (len(command) == 1) & (command[0] == u'?????'):
#********************************************************
	use = 0
	commhelp = ''
	if set_nomer == '1':
		commhelp += u'[#]'
	if set_conf == '1':
		commhelp += u'[conf]'
	if set_botnick == '1':
		commhelp += u'[botnick]'
	if set_allusers == '1':
		commhelp += u'(allusers)'
	if set_redusers == '1':
		commhelp += u'[redusers]'
	if set_yellusers == '1':
		commhelp += u'[yellusers]'
	if set_botstatus == '1':
		commhelp += u'[botrole]'
	if set_botadmin == '1':
		commhelp += u'[botadmin]'

	out = u'List of conf total: ('+str(len(GROUPCHATS.keys()))+u'):\n'+commhelp+'\n'
	len_room_mas = len( (GROUPCHATS.keys()) )
	if (parameters != ''):
		if (command[0] == u'find'):
			for i in range(0, len_room_mas):
				if (GROUPCHATS.keys()[i].count(command[1]) > 0):
					botnick = get_bot_nick(GROUPCHATS.keys()[i])
					moder = 0
					member = 0
					botadmin = 0
					allusers = 0
					use += 1
					for j in range(0, len(GROUPCHATS[GROUPCHATS.keys()[i]].keys())):
						if GROUPCHATS[GROUPCHATS.keys()[i]][GROUPCHATS[GROUPCHATS.keys()[i]].keys()[j]]['ishere'] == 1:
	
							jid_nick = GROUPCHATS.keys()[i]+'/'+GROUPCHATS[GROUPCHATS.keys()[i]].keys()[j]
							dsource = [jid_nick, 'GROUPCHATS.keys()[i]', 'GROUPCHATS[GROUPCHATS.keys()[i]].keys()[j]']
							if user_level(dsource, GROUPCHATS.keys()[i]) > 65:
								botadmin = botadmin + 1

							if GROUPCHATS[GROUPCHATS.keys()[i]][GROUPCHATS[GROUPCHATS.keys()[i]].keys()[j]]['ismoder'] == 1:
								moder = moder + 1
							if GROUPCHATS[GROUPCHATS.keys()[i]][GROUPCHATS[GROUPCHATS.keys()[i]].keys()[j]]['ismoder'] == 0:
								member = member + 1
							allusers = moder + member

							status = u'<admin>'
							if (moder == 0) & (member == 0):
								status = u'<error>'
							if (moder == 0) & (member > 0) & (len(GROUPCHATS.keys()) > 0):
								status = u'<no admin>'
							if (GROUPCHATS.keys()[i].count('@conference.'+set_serverdef) > 0) & (set_shortserver == '1'):
								ff = GROUPCHATS.keys()[i].split('@')
								conf = ff[0] + '@...'
							else:
								conf = GROUPCHATS.keys()[i]
							if botadmin > 0:
								bbotadmin = str(botadmin)
							else:
								bbotadmin = ''
					if set_nomer == '1':
						out +=str(i+1)+'. '
					if set_conf == '1':
						out +=conf + ' '
					if set_botnick == '1':
						out +='['+botnick+']'
					if set_allusers == '1':
						out +='(' + str(allusers) +')'
					if set_redusers == '1':
						out +=str(moder)
					if set_yellusers == '1':
						out +='/'+str(member)
					if set_botstatus == '1':
						out +=' ' + status + ' '
					if set_botadmin == '1':
						out +=bbotadmin
					out +='\n'

		#out +=str(i+1)+'. '+conf +' ['+botnick+'] (' + str(allusers) +') '+str(moder)+'/'+str(member)+' '+status+' '+bbotadmin+'\n'
			if use > 0:
				out = u'found '+str(use)+u' conf:\n' + out
#				msg(source[1], out)
				reply(type, source, out)
			if use == 0:
				out = u'nothing found :-('
#				msg(source[1], out)
				reply(type, source, out)
			return

	if (parameters == ''):
		for i in range(0, len_room_mas):
			if (GROUPCHATS.keys()[i].count('@')):
				botnick = get_bot_nick(GROUPCHATS.keys()[i])
				moder = 0
				member = 0
				botadmin = 0
				allusers = 0
				for j in range(0, len(GROUPCHATS[GROUPCHATS.keys()[i]].keys())):
					if GROUPCHATS[GROUPCHATS.keys()[i]][GROUPCHATS[GROUPCHATS.keys()[i]].keys()[j]]['ishere'] == 1:
						use += 1
						jid_nick = GROUPCHATS.keys()[i]+'/'+GROUPCHATS[GROUPCHATS.keys()[i]].keys()[j]
						dsource = [jid_nick, 'GROUPCHATS.keys()[i]', 'GROUPCHATS[GROUPCHATS.keys()[i]].keys()[j]']
						if user_level(dsource, GROUPCHATS.keys()[i]) > 65:
							botadmin = botadmin + 1

						if GROUPCHATS[GROUPCHATS.keys()[i]][GROUPCHATS[GROUPCHATS.keys()[i]].keys()[j]]['ismoder'] == 1:
							moder = moder + 1
						if GROUPCHATS[GROUPCHATS.keys()[i]][GROUPCHATS[GROUPCHATS.keys()[i]].keys()[j]]['ismoder'] == 0:
							member = member + 1
						allusers = moder + member

						status = u'<admin>'
						if (moder == 0) & (member == 0):
							status = u'<error>'
						if (moder == 0) & (member > 0) & (len(GROUPCHATS.keys()) > 0):
							status = u'<no admin>'
						if (GROUPCHATS.keys()[i].count('@conference.'+set_serverdef) > 0) & (set_shortserver == '1'):
							ff = GROUPCHATS.keys()[i].split('@')
							conf = ff[0] + '@...'
						else:
							conf = GROUPCHATS.keys()[i]
						if botadmin > 0:
							bbotadmin = str(botadmin)
						else:
							bbotadmin = ''
				if set_nomer == '1':
					out +=str(i+1)+'. '
				if set_conf == '1':
					out +=conf + ' '
				if set_botnick == '1':
					out +='['+botnick+']'
				if set_allusers == '1':
					out +='(' + str(allusers) +')'
				if set_redusers == '1':
					out +=str(moder)
				if set_yellusers == '1':
					out +='/'+str(member)
				if set_botstatus == '1':
					out +=' ' + status + ' '
				if set_botadmin == '1':
					out +=bbotadmin
				out +='\n'

		#out +=str(i+1)+'. '+conf +' ['+botnick+'] (' + str(allusers) +') '+str(moder)+'/'+str(member)+' '+status+' '+bbotadmin+'\n'

		if use > 0:
#			msg(source[1], out)
			reply(type, source, out)
		if use == 0:
#			out = u'nothing else :-('
			msg(source[1], out)
			reply(type, source, out)
		return


def admin_searchman(type, source, parameters):
	jid = parameters
	confs = ''
	t = 0
	
	for i in range(0, len(GROUPCHATS.keys())):
		for j in range(0, len(GROUPCHATS[GROUPCHATS.keys()[i]].keys())):
			#confs += GROUPCHATS.keys()[i]
			#print str(i) + ' ' + str(j) 
			truejid = get_true_jid(GROUPCHATS.keys()[i]+'/'+GROUPCHATS[GROUPCHATS.keys()[i]].keys()[j])
			#print truejid
			truejid = truejid.lower()
			nick = GROUPCHATS[GROUPCHATS.keys()[i]].keys()[j]
			jid = jid.lower()
			nick = nick.lower()
			if (truejid.count(jid)>0) | (nick.count(jid)>0):
				t += 1
				confs += str(t)+'. '+ GROUPCHATS.keys()[i] + ' ('+GROUPCHATS[GROUPCHATS.keys()[i]].keys()[j]+') '+truejid+'\n'
	if confs == '':
		aa = u'upon request, I did not find it! =('
		reply(type,source,u'sent to private')
	else:
		aa = u'The user found at:\n[#][conf][(nick)][jid]\n'+ confs
		reply(type,source,u'sent to private')
	reply('private', source, aa)

def admin_getglobadmin(type, source, parameters):
        res = u'list of global access:\n[#][jid][access]'
        i = 0
        if len(GLOBACCESS) == 1:
                reply(type, source, u'no global access found')
                return
        for jid in GLOBACCESS:
                i += 1
                res += '\n'+str(i)+'. '+jid+': '+str(GLOBACCESS[jid])
#                reply(type,source,u'sent to private')
        reply('private', source, res)


                
def admin_getlocaladminthisconf(type, source, parameters):
        res = u'list of local access <'+source[1]+u'>:\n[#][jid][access]'
        i = 0
        if not ACCBYCONF.has_key(source[1]):
                reply(type, source, u'no local access found in this conference')
                return
        for jid in ACCBYCONF[source[1]]:
                i += 1
                res += '\n'+str(i)+'. '+jid+': '+str(ACCBYCONF[source[1]][jid])
#                reply(type,source,u'sent to private')
        reply('private', source, res)

        
def admin_getlocaladminallconf(type, source, parameters):
        res = u'list of local access of all conf ('+str(len(GROUPCHATS))+u'):\n[#][conf][jid][access]'
        i = 0
        if len(ACCBYCONF) == 0:
                reply(type, source, u'no local access found')
                return
        for conf in ACCBYCONF:
                for jid in ACCBYCONF[conf]:
                        i += 1
                        res += '\n'+str(i)+'. '+conf+' '+jid+': '+str(ACCBYCONF[conf][jid])
#                reply(type,source,u'sent to private')
        reply('private', source, res)
        

def admin_setmsglim(type, source, parameters):
        try:
                a = 0
                a += int(parameters)
        except:
                reply(type, source, u'not sure option!')
                return
        reply(type, source, u'setup limit '+str(a)+u' characters.')
        GCHCFGS[source[1]]['msglim'] = a
        MSGLIM = GCHCFGS[source[1]]['msglim']
        DBPATH='dynamic/'+source[1]+'/config.cfg'
        write_file(DBPATH, str(GCHCFGS[source[1]]))


register_command_handler(admin_getglobadmin, 'glob_access', ['superadmin','admin','all', 'new'], 100, 'Display all global access', 'glob_access', ['glob_access'])
register_command_handler(admin_getlocaladminthisconf, 'local_access', ['admin','all', 'new'], 20, 'Extended command "washere".\nDisplay local access this conference', 'local_access', ['local_access'])
register_command_handler(admin_getlocaladminallconf, 'local_access_all', ['superadmin','admin','all', 'new'], 100, 'Show local access to all conferences. WARNING! Huge list could be listed', 'local_access_all', ['local_access_all'])
register_command_handler(admin_getlistconf, 'xwhereami', ['all', 'new'], 20, 'Extended command "whereami".\nDisplay list of conferences where the boat sits and additional information, such as the bot`s nickname in the conference, number of users, red and yellow users, botstatus (currently there are 3 status, "<admin>" means that botrole as admin, "<not admin>" - means that the botrole not an admin, respectively, can not work, "<error>" - Unknown error. Likely the bot performance in the conference impaired.) and botadmin number of admin bot in conf.', 'Customize the list of display information in a conferences, use command options:\n * number - show the show the number serial (answers 1 or 0) \n * conf - display conf (answers 1 or 0)\n * botnick - display botnick (answers 1 or 0)\n * allusers - display user in conf (answers 1 or 0)\n * redusers - display the moderators (answers 1 or 0)\n * yellusers - display yellow users, member/participants (answers 1 or 0)\n * botstatus - display role of bot (answers 1 or 0)\n * botadmin - display number of bot admin (answers 1 or 0)\n ** shortserver - use "short server" (answers 1 or 0)\n ** serverdef - specify the default server (default jsmart.web.id)\n *** find - search for combinations of letters in the conference', ['xwhereami', 'xwhereami find sex', 'xwhereami number 1'])
register_command_handler(admin_searchman, 'search', ['all', 'admin', 'new'], 20, 'Search a combination of letters, characters of a nicks/JID of all the users in conferences where the bot sits', 'search <combination of letters>', ['search guy', 'search jsmart.web.id', 'search jabber.ru'])
register_command_handler(admin_setmsglim, 'msglim', ['admin', 'new', 'all'], 20, 'Set message limit on groupchat. If the message length exceeds limit, it will sent to the private user who made the request.\nP.S.: Function msg was modifying a way that there is now a third parameter passed nickname causing, and if it does not happen, then the entire text (even exceeding the limit) fall in a ?????!', 'msglim <limit>', ['msglim 500'])