#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  automember_plugin.py
#  coded by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################


def handler_automember(groupchat, nick, reason):
   iq = xmpp.Iq('set')
   iq.setID('ulti_member')
   iq.setTo(groupchat)
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   member=query.addChild('item', {'jid':nick+'@nimbuzz.com', 'affiliation':'member'})
   member.setTagData('reason', get_bot_nick(groupchat)+u': '+reason)
   iq.addChild(node=query)
   JCON.send(iq)

def automember_join(groupchat, nick, aff, role):
	DBPATH='dynamic/'+groupchat+'/config.cfg'
	time.sleep(10.0)
	if GROUPCHATS.has_key(groupchat):
	   if GROUPCHATS[groupchat][nick]['ishere']==1:
			if GCHCFGS[groupchat].has_key('automember'):
				pass
			else:
		           GCHCFGS[groupchat]['automember']=1
			   write_file(DBPATH,str(GCHCFGS[groupchat]))
			if GCHCFGS[groupchat]['automember']==1:
				if aff in ('owner', 'admin', 'member'):
					pass
				else:
					handler_automember(groupchat, nick, u'Automember is active')
	if nick == DEFAULT_NICK:
		if GCHCFGS[groupchat].has_key('automember'):
			if GCHCFGS[groupchat]['automember']==1:
				msg(ADMINS[0], u'NOTIFICATION :\nAutomember is active in '+groupchat+'\nSend "automember 0" to De-Activate it')


def handler_automember_onoff(type, source, parameters):

	if not source[1] in GROUPCHATS:
		reply(type, source, u'This command only possible in the conference')
		return
	if parameters:
		try:
			parameters=int(parameters.strip())
		except:
			reply(type,source,u'Read "help automember"')
			return		
		DBPATH='dynamic/'+source[1]+'/config.cfg'
		if parameters==1:
			if GCHCFGS[source[1]]['automember']==1:
				reply(type,source,u'Automember is Already Enabled !')
				return
			else:
				GCHCFGS[source[1]]['automember']=1
				GCHCFGS[source[1]]['autobanall']=0
				reply(type,source,u'Automember Enabled !')
				pass
		else:
			GCHCFGS[source[1]]['automember']=0
			reply(type,source,u'Automember Disabled')
		write_file(DBPATH,str(GCHCFGS[source[1]]))
		if GCHCFGS[source[1]]['automember']==1:
			msg(ADMINS[0], u'NOTIFICATION :\nAutomember Enabled in '+source[1]+'\nSend "automember 0" to Disable it')
	else:
		ison=GCHCFGS[source[1]]['automember']
		if ison==1:
			reply(type,source,u'Automember is Enabled here')
		else:
			reply(type,source,u'Automember is Disabled here')	
   


register_join_handler(automember_join)
register_command_handler(handler_automember_onoff, 'automember', ['admin','muc','all'], 100, 'Off (0) On (1) bot will make member to all user ids below than member role', 'automember [conf] [1|0]', ['automember 1','automember 0','automember'])
