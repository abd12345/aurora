#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  avatar_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

def handler_avatar(type, source, parameters):
	if parameters:
      		reply(type, source, u'http://avatar.nimbuzz.com/getAvatar?jid='+parameters+'%40nimbuzz.com')
		return
	if not parameters:
      		reply(type, source, u'read "help avatar')


register_command_handler(handler_avatar, 'avatar', ['info','muc','all'], 0, 'It gives you a link to a user\'s Display picture', 'avatar <ID without @nimbuzz.com>', ['avatar kforkingfisher'])