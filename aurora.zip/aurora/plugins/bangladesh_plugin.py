#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  BANGLADESH_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################


##############################################################
## ????????? ??????? #########################################
BANGLADESH_QUIZ_FILE = 'static/bangladesh.txt' # ???? ? ?? ###############
BANGLADESH_QUIZ_TOTAL_LINES = 11 # ?????????? ???????? ? ?? ##########
BANGLADESH_QUIZ_TIME_LIMIT = 200 # ??????? ? ???????? ###################
BANGLADESH_QUIZ_IDLE_LIMIT = 3 # ?????????? ????????? ?? OFF ############
##############################################################
BANGLADESH_QUIZ_RECURSIVE_MAX = 20 # empty ##############################
BANGLADESH_QUIZ_CURRENT_ANSWER = {} #####################################
BANGLADESH_QUIZ_CURRENT_HINT = {} #######################################
BANGLADESH_QUIZ_CURRENT_HINT_NEW = {} ###################################
BANGLADESH_QUIZ_CURRENT_TIME = {} #######################################
BANGLADESH_QUIZ_IDLENESS = {} ###########################################
BANGLADESH_QUIZ_IDLE_ANSWER = {}
BANGLADESH_QUIZ_START = {}
BANGLADESH_QUIZ_IDLE_ANSWER_FIRSR = {}
BANGLADESH_QUIZ_NOWORD = '*' # ?????? ???????? "?? ???????? ?????" ######
##############################################################
MODE = 'M1' # ?????. M1 - ????? ??? ??????, M2 - ?????? ??? ##
PTS = 'P2'  # ?????????? ?????: ##############################
ACC = 'A2'  # ??????? ??????? ? !??: A1 - ???, A2 - ??? ????##
############# ???????? ????????? ??? ?????????              ##
## P1 - ??????? / ?????_?????? / 3+1 / ???-?? ???????? ???? ##
## P2 - (??????? / ?????_??????) / (?????_????._????? / 10) ##
## * ?????? ??????? ????? ???? ? ???????? 0 - 5 ? ???????? ###
## * ?????? ??????? ???? ????? ??????? ?????? ??????, ?????? #
##   ?????? ??? ???? ?? 0 ?? 50 (????? ???? ?? ?????????? ?? #
##   ?? ???????, ?? ??? ??? ????? ???????? ??? 1) ############
##############################################################
###%%%%%%###%%%%%%#####%%%%%%#################################
##%%####%%####%%######%%####%%################################
##%%##########%%######%%######################################
##%%##%%%%####%%######%%##%%%%################################
##%%##%%%%####%%######%%##%%%%################################
##%%####%%####%%######%%####%%################################
###%%%%%%###%%%%%%#####%%%%%%#################################
##############################################################

import threading

HELP = u'help of command > "!bangladesh"'


def sectomin(time):
        m = 0
        s = 0
        if time >= 60:
                m = time / 60
                
                if (m * 60) != 0:
                        s = time - (m * 60)
                else:
                        s = 0
        else:
                m = 0
                s = time
                

        return str(m)+u'min. & '+str(s)+u'sec.'


def bangla_timer(groupchat, start_time):
        global BANGLADESH_QUIZ_TIME_LIMIT
        global BANGLADESH_QUIZ_CURRENT_TIME
        
	time.sleep(BANGLADESH_QUIZ_TIME_LIMIT)
	if BANGLADESH_QUIZ_CURRENT_TIME.has_key(groupchat) and BANGLADESH_QUIZ_CURRENT_ANSWER.has_key(groupchat) and start_time == BANGLADESH_QUIZ_CURRENT_TIME[groupchat]:
		BANGLADESH_QUIZ_CURRENT_ANSWER[groupchat]
		msg(groupchat, u'(!) time out! ' + sectomin(BANGLADESH_QUIZ_TIME_LIMIT) + u' passed.\nCorrect answer: ' + BANGLADESH_QUIZ_CURRENT_ANSWER[groupchat])
		if BANGLADESH_QUIZ_IDLENESS.has_key(groupchat):
			BANGLADESH_QUIZ_IDLENESS[groupchat] += 1
		else:
			BANGLADESH_QUIZ_IDLENESS[groupchat] = 1
		if BANGLADESH_QUIZ_IDLENESS[groupchat] >= BANGLADESH_QUIZ_IDLE_LIMIT:
			msg(groupchat, u'(!) bangla will be automatically completed for inaction! ' + str(BANGLADESH_QUIZ_IDLE_LIMIT) + ' unanswered questions.')
			del BANGLADESH_QUIZ_CURRENT_ANSWER[groupchat]
			bangla_list_scores(groupchat)
		else:
			bangla_ask_question(groupchat)

def bangla_new_question():
        global BANGLADESH_QUIZ_RECURSIVE_MAX
        
	line_num = random.randrange(10)
	fp = file(BANGLADESH_QUIZ_FILE)
	for n in range(line_num + 1):
		if n == line_num:
			(question, answer) = string.split(fp.readline().strip(), '|', 1)
			return (unicode(question, 'utf-8'), unicode(answer, 'utf-8'))
		else:
			fp.readline()

def bangla_ask_question(groupchat):
        global answer
        global BANGLADESH_QUIZ_CURRENT_TIME
        global question
        global BANGLADESH_QUIZ_IDLE_ANSWER
        global BANGLADESH_QUIZ_IDLE_ANSWER_FIRSR
        BANGLADESH_QUIZ_IDLE_ANSWER = {groupchat:{}}
	(question, answer) = bangla_new_question()
	BANGLADESH_QUIZ_CURRENT_ANSWER[groupchat] = answer
	BANGLADESH_QUIZ_CURRENT_HINT[groupchat] = None
	BANGLADESH_QUIZ_CURRENT_HINT_NEW[groupchat] = None
	BANGLADESH_QUIZ_CURRENT_TIME[groupchat] = time.time()
	threading.Thread(None, bangla_timer, 'gch'+str(random.randrange(0,9999)), (groupchat, BANGLADESH_QUIZ_CURRENT_TIME[groupchat])).start()
	msg(groupchat, u'(?) question: \n' + question)

def bangla_ask_new_question(groupchat, ans):
        global BANGLADESH_QUIZ_CURRENT_TIME
        global answer
        global question
        global BANGLADESH_QUIZ_IDLE_ANSWER
        global BANGLADESH_QUIZ_IDLE_ANSWER_FIRSR
        BANGLADESH_QUIZ_IDLE_ANSWER = {groupchat:{}}
	(question, answer) = bangla_new_question()
	BANGLADESH_QUIZ_CURRENT_ANSWER[groupchat] = answer
	BANGLADESH_QUIZ_CURRENT_HINT[groupchat] = None
	BANGLADESH_QUIZ_CURRENT_HINT_NEW[groupchat] = None
	BANGLADESH_QUIZ_CURRENT_TIME[groupchat] = time.time()
	threading.Thread(None, bangla_timer, 'gch'+str(random.randrange(0,9999)), (groupchat, BANGLADESH_QUIZ_CURRENT_TIME[groupchat])).start()
	msg(groupchat, u'(!) correct answer: '+ans+u', changing question: \n' + question)
	
def bangla_answer_question(groupchat, nick, answer):
        global BANGLADESH_QUIZ_IDLE_ANSWER
        global BANGLADESH_QUIZ_IDLE_ANSWER_FIRSR
        
	DBPATH='dynamic/'+groupchat+'/bangla.cfg'
	if check_file(groupchat,'bangla.cfg'):
		BANGLADESH_QUIZ_SCORES = eval(read_file(DBPATH))
	jid = get_true_jid(groupchat+'/'+nick)
	jid = jid.lower()
	
	if BANGLADESH_QUIZ_CURRENT_ANSWER.has_key(groupchat):
                answer1 = BANGLADESH_QUIZ_CURRENT_ANSWER[groupchat].lower()
                answer2 = answer.lower()
                if answer1 == answer2:
                        if BANGLADESH_QUIZ_IDLE_ANSWER.has_key(groupchat):
                                if len(BANGLADESH_QUIZ_IDLE_ANSWER[groupchat]) != 0:
                                        if BANGLADESH_QUIZ_IDLE_ANSWER[groupchat].has_key(jid):
                                                if BANGLADESH_QUIZ_IDLE_ANSWER[groupchat][jid][1] == '1':
                                                        msg(groupchat, nick+u': you have answered correctly!')
                                                else:
                                                        razn = BANGLADESH_QUIZ_IDLE_ANSWER[groupchat][jid][0] - BANGLADESH_QUIZ_IDLE_ANSWER_FIRSR[groupchat]
                                                        msg(groupchat, nick+u': you have answered correctly, ??????? ?? %.3f sec' % razn)
                                        else:
                                                BANGLADESH_QUIZ_IDLE_ANSWER[groupchat][jid] = [time.time(), '0']
                                                
                                                razn = BANGLADESH_QUIZ_IDLE_ANSWER[groupchat][jid][0] - BANGLADESH_QUIZ_IDLE_ANSWER_FIRSR[groupchat]
                                                msg(groupchat, nick+u': you answered correctly, but %.3f sec late' % razn)
                                        return

			if BANGLADESH_QUIZ_IDLENESS.has_key(groupchat):
				del BANGLADESH_QUIZ_IDLENESS[groupchat]
			answer_time = int(time.time() - BANGLADESH_QUIZ_CURRENT_TIME[groupchat])
			try:
                                if MODE == 'M1':
                                        alen = len(BANGLADESH_QUIZ_CURRENT_HINT_NEW[groupchat])
                                        blen = BANGLADESH_QUIZ_CURRENT_HINT_NEW[groupchat].count('')
                                        a = alen - blen
                                if MODE == 'M2':
                                        a = 0
                                        a = a + BANGLADESH_QUIZ_CURRENT_HINT[groupchat]
                        except:
                                a = 1
                        if PTS == 'P1':
                                points = BANGLADESH_QUIZ_TIME_LIMIT / answer_time / 3 + 1 / a
                        if PTS == 'P2':
                                try:
                                        alen = len(BANGLADESH_QUIZ_CURRENT_HINT_NEW[groupchat])
                                        blen = BANGLADESH_QUIZ_CURRENT_HINT_NEW[groupchat].count('')
                                        a = alen - blen
                                        procent = a * 100 / alen
                                except:
                                        procent = 10
                                
                                points = (BANGLADESH_QUIZ_TIME_LIMIT / answer_time) / (procent / 10)

			if points == 0:
                                pts = '0'
                        else:
                                pts = '+'+str(points)
			msg(groupchat, u'congratulations ! ' + nick + u'  You get ' + pts + u' points. \nCorrect answer is: ' + answer)			
			if not BANGLADESH_QUIZ_SCORES.has_key(groupchat):
				BANGLADESH_QUIZ_SCORES[groupchat] = {}
			if BANGLADESH_QUIZ_SCORES[groupchat].has_key(jid):
				BANGLADESH_QUIZ_SCORES[groupchat][jid][0] += points
				BANGLADESH_QUIZ_SCORES[groupchat][jid][1] += points
				BANGLADESH_QUIZ_SCORES[groupchat][jid][2] = nick
				BANGLADESH_QUIZ_SCORES[groupchat][jid][3] += 1
			else:
				BANGLADESH_QUIZ_SCORES[groupchat][jid] = [points, points, nick, 1]
			
#			bangla_list_scores(groupchat)


                        BANGLADESH_QUIZ_IDLE_ANSWER[groupchat][jid] = [time.time(), '1']
                        BANGLADESH_QUIZ_IDLE_ANSWER_FIRSR[groupchat] = time.time()

                        if BANGLADESH_QUIZ_IDLE_ANSWER.has_key(groupchat):
                                if len(BANGLADESH_QUIZ_IDLE_ANSWER[groupchat]) == 1:
                                        time.sleep(5.0)
                                        bangla_ask_question(groupchat)
	write_file(DBPATH, str(BANGLADESH_QUIZ_SCORES))

def swap(arr, i, j):
    arr[i], arr[j] = arr[j], arr[i]
 
def sort(groupchat, mas, sort=1, count=10):
        base = mas[groupchat]
        arr = []
        str1 = ''
        for a in base:
                asd = base[a][sort]
                arr += [asd]
        i = len(arr)
        while i > 1:
                for j in xrange(i - 1):
                        if arr[j] < arr[j + 1]:
                                swap(arr, j, j + 1)
                i -= 1
        top10 = 1
        prim = ''
        charcount = 0

        for z in arr:                       
                for x in base:
                        nick = base[x][2]
                        if len(nick) > charcount:
                                charcount = len(nick)
                        
        for z in arr:                       
                for x in base:
                        nick = base[x][2]
                        if len(nick) < charcount:
                                nick += ' ' * (charcount - len(nick))
                        nick += ' '
                                
                        if base[x][sort] == z:
                                str1 += str(top10)+'. '+nick+' '+str(base[x][0])+'-'+str(base[x][1])+'-'+str(base[x][3])+'\n'
                                if top10 < count:
                                        top10 += 1
                                else:
                                        str1 = prim + str1
                                        return str1
        str1 = prim + str1
        return str1



def bangla_list_scores(groupchat, sort_=1, count=10):
	DBPATH='dynamic/'+groupchat+'/bangla.cfg'
	if check_file(groupchat,'bangla.cfg'):
		BANGLADESH_QUIZ_SCORES = eval(read_file(DBPATH))

        if BANGLADESH_QUIZ_SCORES.has_key(groupchat):
                if BANGLADESH_QUIZ_SCORES[groupchat]:
                        if BANGLADESH_QUIZ_IDLENESS.has_key(groupchat):
                                del BANGLADESH_QUIZ_IDLENESS[groupchat]
                        if BANGLADESH_QUIZ_CURRENT_ANSWER.has_key(groupchat):
                                result = u'(*) list of scores:\n[#][Nick][Current][Total][Answer]\n'
                        else:
                                result = u'(*) list of scores:\n[Nick][Last][Total][Answer]\n'
                        result = result+sort(groupchat, BANGLADESH_QUIZ_SCORES, sort_, count)

			msg(groupchat, result)

def handler_bangla_start(type, source, parameters):
	groupchat = source[1]
	DBPATH='dynamic/'+groupchat+'/bangla.cfg'
	if check_file(groupchat,'bangla.cfg'):
		BANGLADESH_QUIZ_SCORES = eval(read_file(DBPATH))
        jid = get_true_jid(source[1]+'/'+source[2])
        jid = jid.lower()
	if not groupchat:
		reply(type, source, u'not in private')
		return
	if BANGLADESH_QUIZ_CURRENT_ANSWER.has_key(groupchat):
		reply(type, source, u'bangla exists! '+HELP)
		return
	
	if not BANGLADESH_QUIZ_SCORES.has_key(groupchat):
                BANGLADESH_QUIZ_SCORES[groupchat] = {}
                write_file(DBPATH, str(BANGLADESH_QUIZ_SCORES))
        if BANGLADESH_QUIZ_SCORES.has_key(groupchat):
                if BANGLADESH_QUIZ_SCORES[groupchat].has_key(jid):
                        for kjid in BANGLADESH_QUIZ_SCORES[groupchat]:
                                BANGLADESH_QUIZ_SCORES[groupchat][kjid][0] = 0
                        
                        write_file(DBPATH, str(BANGLADESH_QUIZ_SCORES))
        BANGLADESH_QUIZ_START[groupchat] = jid
        
	if BANGLADESH_QUIZ_IDLENESS.has_key(groupchat):
		del BANGLADESH_QUIZ_IDLENESS[groupchat]
#	msg(groupchat, u'[?????????] ????????? ??????! ???? ????????.')
	bangla_ask_question(groupchat)

def handler_bangla_stop(type, source, parameters):
	groupchat = source[1]
	if BANGLADESH_QUIZ_CURRENT_ANSWER.has_key(groupchat):
		del BANGLADESH_QUIZ_CURRENT_ANSWER[groupchat]
		msg(groupchat, u'(!) bangla stopped.')
		time.sleep(1.0)
		bangla_list_scores(groupchat, 0, 10)
	else:
		reply(type, source, u'no BANGLADESH Quiz, '+HELP)

def handler_bangla_next(type, source, parameters):
        if BANGLADESH_QUIZ_CURRENT_ANSWER.has_key(source[1]):
                jid = get_true_jid(source[1]+'/'+source[2])
                if ACC == 'A1':
                        bangla_ask_new_question(source[1], BANGLADESH_QUIZ_CURRENT_ANSWER[source[1]])
                if ACC == 'A2':
                        if (jid == BANGLADESH_QUIZ_START[source[1]]) | (user_level(source[1]+'/'+source[2], source[1]) >= 16):
                                bangla_ask_new_question(source[1], BANGLADESH_QUIZ_CURRENT_ANSWER[source[1]])
                        else:
                                reply(type, source, u'This command is allowed only for members, '+HELP)
        else:
                reply(type, source, u'No BANGLADESH Quiz, '+HELP)

def handler_bangla_hint(type, source, parameters):
        global ans
	groupchat = source[1]
        ans = BANGLADESH_QUIZ_CURRENT_ANSWER[groupchat]
	if BANGLADESH_QUIZ_CURRENT_ANSWER.has_key(groupchat):
		if BANGLADESH_QUIZ_IDLENESS.has_key(groupchat):
			del BANGLADESH_QUIZ_IDLENESS[groupchat]
		if BANGLADESH_QUIZ_CURRENT_HINT[groupchat] == None:
			BANGLADESH_QUIZ_CURRENT_HINT[groupchat] = 0
		if MODE == 'M1':
                        if BANGLADESH_QUIZ_CURRENT_HINT_NEW[groupchat] == None:
                                ms = ['']
                                BANGLADESH_QUIZ_CURRENT_HINT_NEW[groupchat] = []
                                for r in range(0, len(BANGLADESH_QUIZ_CURRENT_ANSWER[groupchat])):
                                        BANGLADESH_QUIZ_CURRENT_HINT_NEW[groupchat] += ms

                        ex = 1
                        while ex == 1:
                                a = random.choice(BANGLADESH_QUIZ_CURRENT_ANSWER[groupchat])
                                if not a in BANGLADESH_QUIZ_CURRENT_HINT_NEW[groupchat]:
                                        for t in range(0, len(BANGLADESH_QUIZ_CURRENT_ANSWER[groupchat])):
                                                if BANGLADESH_QUIZ_CURRENT_ANSWER[groupchat][t] == a:
                                                        BANGLADESH_QUIZ_CURRENT_HINT_NEW[groupchat][t] = a
                                                        ex = 0
                                hint = '' 
                        for hnt in BANGLADESH_QUIZ_CURRENT_HINT_NEW[groupchat]:
                                if hnt == '':
                                        hint += BANGLADESH_QUIZ_NOWORD
                                else:
                                        hint += hnt
                        if not '' in BANGLADESH_QUIZ_CURRENT_HINT_NEW[groupchat]:
                                bangla_ask_new_question(source[1], ans)
                        else:
                                msg(groupchat, u'(*) hint: ' + hint)
                if MODE == 'M2':
                        BANGLADESH_QUIZ_CURRENT_HINT[groupchat] += 1
                        hint = BANGLADESH_QUIZ_CURRENT_ANSWER[groupchat][0:BANGLADESH_QUIZ_CURRENT_HINT[groupchat]]
                        hint += ' *' * (len(BANGLADESH_QUIZ_CURRENT_ANSWER[groupchat]) - BANGLADESH_QUIZ_CURRENT_HINT[groupchat])
                        msg(groupchat, u'(*) hint: ' + hint)
                        if (len(BANGLADESH_QUIZ_CURRENT_ANSWER[groupchat]) - BANGLADESH_QUIZ_CURRENT_HINT[groupchat]) == 0:
                                bangla_ask_new_question(source[1], ans)
	else:
		reply(type, source, u'no bangla, '+HELP)

def handler_bangla_answer(type, source, parameters):
        global answer
        reply(type, source, answer)



def handler_bangla_scores(type, source, parameters):
	groupchat = source[1]
	
	DBPATH='dynamic/'+groupchat+'/bangla.cfg'
	if check_file(groupchat,'bangla.cfg'):
		BANGLADESH_QUIZ_SCORES = eval(read_file(DBPATH))

	if BANGLADESH_QUIZ_SCORES.has_key(groupchat):
                if BANGLADESH_QUIZ_SCORES[groupchat]:
                        if BANGLADESH_QUIZ_CURRENT_ANSWER.has_key(source[1]):
                                bangla_list_scores(groupchat, 0, 10)
                        else:
                                bangla_list_scores(groupchat, 1, 10)
                else:
                        reply(type, source, u'the database is empty, '+HELP)
        else:
                reply(type, source, u'the database is empty, '+HELP)

def handler_bangla_message(type, source, body):
	groupchat = source[1]
	if groupchat and BANGLADESH_QUIZ_CURRENT_ANSWER.has_key(groupchat):
		bangla_answer_question(source[1], source[2], body.strip())

def handler_bangla_resend(type, source, body):
        global question
        groupchat = source[1]
        if BANGLADESH_QUIZ_CURRENT_ANSWER.has_key(groupchat):
                res = u'(*) current question: \n'+question
                reply(type, source, res)
        else:
                reply(type, source, u'no bangla, '+HELP)

def handler_bangla_help(type, source, body):
        if BANGLADESH_QUIZ_CURRENT_ANSWER.has_key(source[1]):
                stat = u'running'
        else:
                stat = u'not running'
        res = u'BANGLADESHQuiz By: \nABDULLAH \nQuiz Status: '+stat+u'\nDatabase: '+str(BANGLADESH_QUIZ_TOTAL_LINES)+u' Questions\nCommand:\n- .start - start bangla\n- .stop - start bangla\n- .repeat - repeat question\n- .hint - find an answer tip (removes points)\n- .next - next question\n- .score - conclusion of the current score\n- .base_del - remove all the statistics for the conf (without parameter), or with user (jid parameter)\n+ sort statistics (during the game on the current account, at the end of the game on the current score)\n+ formatting statistics\n+ clearing statistics'
        if MODE == 'M1':
                m = u'* new type of hint (randomly)'
        if MODE == 'M2':
                m = u'* old type of hint'
        if PTS == 'P1':
                p = u'* old type of calculation points'
        if PTS == 'P2':
                p = u'* new type of calculation points'
        if ACC == 'A1':
                a = u'* access .next for all'
        if ACC == 'A2':
                a = u'* access .next only for user created the bangla and moderators'
        res+= u'\nConfiguration:\n'+m+'\n'+p+'\n'+a
        reply(type, source, res)


def handler_bangla_base_del(type, source, body):
	groupchat = source[1]
	
	DBPATH='dynamic/'+groupchat+'/bangla.cfg'
	if check_file(groupchat,'bangla.cfg'):
		BANGLADESH_QUIZ_SCORES = eval(read_file(DBPATH))

	if body == '':
                if BANGLADESH_QUIZ_SCORES.has_key(source[1]):
                        del BANGLADESH_QUIZ_SCORES[source[1]]
                        reply(type, source, u'<!> database has been completely cleared!')
                else:
                        reply(type, source, u'<!> database empty!')
        else:
                if BANGLADESH_QUIZ_SCORES.has_key(source[1]):
                        if BANGLADESH_QUIZ_SCORES[source[1]].has_key(body):
                                del BANGLADESH_QUIZ_SCORES[source[1]][body]
                                reply(type, source, u'<!> database jid has been removed')
                        else:
                                reply(type, source, u'<!> database empty!')


                else:
                        reply(type, source, u'<!> database has been completely cleared!')
        write_file(DBPATH, str(BANGLADESH_QUIZ_SCORES))
        
        

register_command_handler(handler_bangla_start, '.start', ['new','quiz','all'], 20, 'Start bangla.', '.start', ['.start'])
register_command_handler(handler_bangla_help, '!bangladesh', ['new','quiz','all'], 0, 'Conclusion HELP.', '!BANGLADESH', ['!BANGLADESH'])
register_command_handler(handler_bangla_resend, '.repeat', ['new','quiz','all'], 0, 'Repeat current question.', '.repeat', ['.repeat'])
register_command_handler(handler_bangla_stop, '.stop', ['new','quiz','all'], 20, 'Stop bangla.', '.stop', ['.stop'])
register_command_handler(handler_bangla_hint, '.hint', ['new','quiz','all'], 0, 'Find an answer tip (??).', '.hint', ['.hint'])
register_command_handler(handler_bangla_scores, '.score', ['new','quiz','all'], 0, 'Display conclusion of the current score (nickname, total points).', '.score', ['.score'])
register_command_handler(handler_bangla_next, '.next', ['new','quiz','all'], 0, 'Next question.', '.next', ['.next'])
register_command_handler(handler_bangla_answer, '.answer', ['new','quiz','all'], 100, 'Display correct answer <CHEAT>.', '.answer', ['.answer'])
register_command_handler(handler_bangla_base_del, '.base_del', ['new','quiz','all'], 100, 'Delete all the database.', '.base_del [JID]', ['.base_del guy@jsmart.web.id', '.base_del'])

register_message_handler(handler_bangla_message)
