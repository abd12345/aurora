#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  dict_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

import DICT
import urllib

def handler_dict_define(type, source, parameters):
	dc = DICT.DictConnection('dict.org')
	try:
		results = dc.get_definition(parameters.strip())
		if len(results):
			#reply = string.join(results[0], '\n')
			reply1 = 'http://www.dict.org/bin/Dict?Form=Dict1&Query=' + urllib.quote(parameters) + '&Strategy=*&Database=*'
			for result in results[:3]:
				reply1 += '\n\n' + string.join(result[:8], '\n')[:500][4:]
				if len(result) > 8:
					reply1 += ' . . .'
			reply1 = reply1.replace('\n\n\n', '\n\n')
		else:
			reply1 = 'No Results'
	except:
		raise
		reply1 = 'Error'
	reply(type, source, reply1)

register_command_handler(handler_dict_define, 'define', ['fun','superadmin','muc','all'], 0, 'Defines a word using the DICT protocol.', 'define <word>', ['define neutron'])
