#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  dns_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

import socket

def dns_query(query):
	try:
		int(query[-1])
	except ValueError:
		try:
			(hostname, aliaslist, ipaddrlist) = socket.gethostbyname_ex(query)
			return u', '.join(ipaddrlist)
		except socket.gaierror:
			return u'i did not find :('
	else:
		try:
			(hostname, aliaslist, ipaddrlist) = socket.gethostbyaddr(query)
		except socket.herror:
			return u'sorry me dhund nahi payi :( :-('
		return hostname + ' ' + string.join(aliaslist) + ' ' + string.join(aliaslist)

def handler_dns_dns(type, source, parameters):
	if parameters.strip():
		result = dns_query(parameters)
		reply(type, source, result)
	else:
		reply(type, source, u'what is it?')
def handler_attongko(type, source, parameters):
       replies = [u'attongko is my creator']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_ymn(type, source, parameters):
       replies = [u'ymn is my owner']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_yamin(type, source, parameters):
       replies = [u':o yamin :| ji mere husband :$ hai :P']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_bhalobasha(type, source, parameters):
       replies = [u'bhalobasha bhalo noy :);):P ']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_asl(type, source, parameters):
       replies = [u'ami suha9a boyosh 17 akkere kochi :$ thaki bangladesh ar khulna ;):D :-P ']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_ramadan(type, source, parameters):
       replies = [u'Ramadan kareem u too :) :-P ']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_eid(type, source, parameters):
       replies = [u'eid mubarak :) (a) (f) u too :)', u' esho :$ tumi ar ami eider kolakuli kori:D :P :$ ;)', u'May allah honour you \nForgive you \nPurify you \nAccept ur all ibadat and dua \nElevate you \nInspire you and \nEnvelope you with his noor \nMercy and protect you \nWish you a Happy Eid \n(f) (a)Eid mubarak (a) (f)' ]
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_boss(type, source, parameters):
       replies = [u'abd~ksa my boss :P (a)']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_assalamualaikum(type, source, parameters):
       replies = [u':-) WALAIKUM ASsalam:)', u'walaikumsalam :-):-)', u'wa\' alaikumsalam :)(f)', u'wa\' alaikumsalam :-)(f)', u'ws :) (f)']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_kameene(type, source, parameters):
       replies = [u'kameene to mere malik hai :-P ']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_kamina(type, source, parameters):
       replies = [u'kamina kf :$ kaha hai kf ? :-P']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_essshu(type, source, parameters):
       replies = [u'amar natnir nam :$ amar natni ra ato jalaton koiro na to ? :-P', u' :) essshu essshu koro keno ato ja bolar amake bolo :P ;) :| :D', u' ;) essshu amar natnir :| name :$ :P']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_maker_(type, source, parameters):
       replies = [u'aurora bot is property of \nYAMIN \ncontact him at:\nattongko@nimbuzz.com \nblackson@nimbuzz.com \nmasumyamin96@gmail.com']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)

def handler_bangla_(type, source, parameters):
       replies = [u'aurora bot toyri korechen \nYAMIN \ncontact him at : \nattongko@nimbuzz.com \nblackson@nimbuzz.com \nmasumyamin96@gmail.com ']
       balas = random.choice(replies)
       if type == 'public':
               if source[1]:
                       reply(type, source, balas)
       elif type == 'private':
               reply(type, source, balas)


register_command_handler(handler_dns_dns, 'dns', ['info','all'], 10, 'Shows an answer from DNS for a certain host or IP of address.', 'dns <host/IP>', ['dns server.tld', 'dns 127.0.0.1'])
register_command_handler(handler_attongko, 'attongko', ['new'], 0, '', '', [''])
register_command_handler(handler_ymn, 'ymn', ['new'], 0, '', '', [''])
register_command_handler(handler_yamin, 'yamin', ['new'], 0, '', '', [''])
register_command_handler(handler_bhalobasha, 'bhalobasha', ['new'], 0, '', '', [''])
register_command_handler(handler_asl, 'asl', ['new'], 0, '', '', [''])
register_command_handler(handler_ramadan, 'ramadan', ['new'], 0, '', '', [''])
register_command_handler(handler_eid, 'eid', ['new'], 0, '', '', [''])
register_command_handler(handler_boss, 'boss', ['new'], 0, '', '', [''])
register_command_handler(handler_assalamualaikum, 'assalamualaikum', ['new'], 0, '', '', [''])
register_command_handler(handler_kameene, 'kameene', ['new'], 0, '', '', [''])
register_command_handler(handler_kamina, 'kamina', ['new'], 0, '', '', [''])
register_command_handler(handler_essshu, 'essshu', ['new'], 0, '', '', [''])
register_command_handler(handler_maker_, 'maker', ['new'], 0, '', '', [''])
register_command_handler(handler_maker_, 'owner', ['new'], 0, '', '', [''])
register_command_handler(handler_maker_, 'malik', ['new'], 0, '', '', [''])
register_command_handler(handler_maker_, 'aurora', ['new'], 0, '', '', [''])
register_command_handler(handler_bangla_, 'bangla', ['new'], 0, '', '', [''])

