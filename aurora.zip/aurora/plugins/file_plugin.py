#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  file_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

filestore_pending=[]
def handler_filestore(type, source, parameters):
        iq = xmpp.Iq('get')
	iq.setID('id')
	iq.setTo('saf.nimbuzz.com')
        query = xmpp.Node('list')
	query.setNamespace('nimbuzz:filestore')
	iq.addChild(node=query)
	JCON.SendAndCallForResponse(iq, handler_filestore_answ, {'type': type, 'source': source})
	return

def handler_filestore_answ(coze, res, type, source):
        
        rep=''
	if res:
                
		if res.getType() == 'result':
                        

                        ch=res.getChildren()
                        if ch:
                                
                                for x in ch:
                                        aa=x.getTags('file')
                                        if aa:
                                                
                                                for z in aa:
                                                        
                                                        files=z.getAttr('name')
                                                        if files:
                                                                rep+=files
                                                                rep+='\n'
                                                                
                                                        

        reply(type, source, rep)



register_command_handler(handler_filestore, 'filestore', ['info','muc','all'], 100, 'Shows the files in bot JID online gallery.', 'filestore', ['filestore'])