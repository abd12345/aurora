#--===auroraplugin===--
# -*- coding: utf-8 -*-
#  aurora plugin
#  horoscope_plugin.py
#  coded by kf (kforkingfisher@/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########

import urllib
import urllib2
import re

from re import compile as re_compile

strip_tags = re_compile(r'<[^<>]+>')

horodb={u'aquarius': u'AQUARIUS', u'cancer': u'CANCER', u'libra': u'LIBRA', u'capricorn': u'CAPRICORN', u'virgo': u'VIRGO', u'gemini': u'GEMINI', u'sagittarius': u'SAGITTARIUS', u'scorpio': u'SCORPIO', u'taurus': u'TAURUS', u'leo': u'LEO', u'aries': u'ARIES', u'pisces': u'PISCES'}


def horo_get(type, source, parameters):
	if parameters:
		if parameters==u'signs':
			reply('private',source,', '.join(horodb.keys()))
			return
		if horodb.has_key(string.lower(parameters)):
			req = urllib2.Request('http://mobile.dispatchhomeandgarden.com/wap/horoscope/display.jsp?sid=90&iid=8&n='+horodb[string.lower(parameters)])
			req.add_header = ('User-agent', 'Mozilla/5.0')
			r = urllib2.urlopen(req)
			target = r.read()
			"""horoscope"""
                	od = re.search('<p class="gray1">',target)
                	b1 = target[od.end():]
                	b1 = b1[:re.search('</p>',b1).start()]
			if len(b1)<5:
				reply(type,source,u'horoscope is not present now')
                		return

			message = b1
			message = decode(message)
			message=message.strip()
			reply(type,source,u'sent to private')
			reply('private',source,unicode(message,'windows-1251'))
		else:
			reply(type, source, u'is that a sign of zodiac?')
			return	
	else:
		reply(type,source,u'what sign of horoscope you want to search?')
		return


def decode(text):
    return strip_tags.sub('', text.replace('<br>','\n')).replace('&nbsp;', ' ').replace('&lt;', '<').replace('&gt;', '>').replace('&quot;', '"').replace('\t','').replace('>[:\n','')



register_command_handler(horo_get, 'horo', ['muc', 'all'], 0, 'Horoscope from the site www.mobile.dispatchhomeandgarden.com', 'Horo <sign>', ['horo leo'])