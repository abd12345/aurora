#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  lockroom_plugin.py
#  coded by kf (kforkingfisher@gmail/nimbuzz.com)

#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

PASSW={}

def handler_lock(type, source, parameters):
	if source[1] in GROUPCHATS.keys():
		DBPATH='dynamic/password.txt'
		password = str(random.randrange(1000, 9999))
		if type != 'private':
			if not parameters:
				node=xmpp.simplexml.XML2Node(unicode("<iq id='ulti_lockroom' to='"+source[1]+"' type='set' xml:lang='en-US'><query xmlns='http://jabber.org/protocol/muc#owner'><x xmlns='jabber:x:data' type='submit'><field var='muc#roomconfig_passwordprotectedroom'><value>1</value></field><field var='muc#roomconfig_roomsecret'><value>"+password+"</value></field></x></query></iq>").encode('utf8'))
				JCON.send(node)
				PASSW[source[1]]=password
				add_gch(source[1], DEFAULT_NICK, password)
				write_file(DBPATH,str(PASSW))
				if PASSW[source[1]]==password:
					msg(ADMINS[0], u'WARNING :\n'+source[1]+' IS LOCKED\nPASSWORD = '+password+'\nSEND ".pass <roomname>" (without "@" part) to Retrieve the password')
					reply(type, source, u'Room locked. Room is Safe Now !')
			if parameters:
				param = parameters.split(' ', 1)
				if len(param) == 1:
					reply(type, source, u'STUPID :-@ This command has to be given in private.\nGive This Command in Private, with another PASSWORD !')
					return
				elif len(param) == 2:
					reply(type, source, u'STUPID :-@ This command has to be given in private.\nGive This Command in Private, with another PASSWORD !')
					return
		else:
			if not parameters:
				node=xmpp.simplexml.XML2Node(unicode("<iq id='ulti_lockroom' to='"+source[1]+"' type='set' xml:lang='en-US'><query xmlns='http://jabber.org/protocol/muc#owner'><x xmlns='jabber:x:data' type='submit'><field var='muc#roomconfig_passwordprotectedroom'><value>1</value></field><field var='muc#roomconfig_roomsecret'><value>"+password+"</value></field></x></query></iq>").encode('utf8'))
				JCON.send(node)
				PASSW[source[1]]=password
				write_file(DBPATH,str(PASSW))
				if PASSW[source[1]]==password:
					msg(ADMINS[0], u'WARNING :\n'+source[1]+' IS LOCKED\nPASSWORD = '+password+'\nSEND ".pass <roomname>" (without "@" part) to Retrieve the password')
					reply(type, source, u'Room locked. Room is Safe Now !')
			if parameters:
				param = parameters.split(' ', 1)
				room=param[0]+'@conference.nimbuzz.com'
				DBPATH='dynamic/password.txt'
				if len(param) == 1:
						try:
							node=xmpp.simplexml.XML2Node(unicode("<iq id='ulti_lockroom' to='"+source[1]+"' type='set' xml:lang='en-US'><query xmlns='http://jabber.org/protocol/muc#owner'><x xmlns='jabber:x:data' type='submit'><field var='muc#roomconfig_passwordprotectedroom'><value>1</value></field><field var='muc#roomconfig_roomsecret'><value>"+param[0]+"</value></field></x></query></iq>").encode('utf8'))
							JCON.send(node)
							PASSW[source[1]]=param[0]
							write_file(DBPATH,str(PASSW))
							if PASSW[source[1]]==param[0]:
								msg(ADMINS[0], u'WARNING :\n'+source[1]+' IS LOCKED\nPASSWORD = '+param[0]+'\nSEND ".pass <roomname>" (without "@" part) to Retrieve the password')
								reply(type, source, u'Room locked. Room is Safe Now !')
						except:
							reply(type,source,u'NOT POSSIBLE AT THE MOMENT !')
							return
				elif len(param) == 2:
					try:
						node=xmpp.simplexml.XML2Node(unicode("<iq id='ulti_lockroom' to='"+room+"' type='set' xml:lang='en-US'><query xmlns='http://jabber.org/protocol/muc#owner'><x xmlns='jabber:x:data' type='submit'><field var='muc#roomconfig_passwordprotectedroom'><value>1</value></field><field var='muc#roomconfig_roomsecret'><value>"+param[1]+"</value></field></x></query></iq>").encode('utf8'))
						JCON.send(node)
						PASSW[room]=param[1]
						write_file(DBPATH,str(PASSW))
						if PASSW[room]==param[1]:
							msg(ADMINS[0], u'WARNING :\n'+param[0]+' IS LOCKED\nPASSWORD = '+param[1]+'\nSEND ".pass <roomname>" (without "@" part) to Retrieve the password')
							reply(type, source, u'Room locked. Room is Safe Now !')
					except:
						reply(type,source,u'NOT POSSIBLE AT THE MOMENT !')
						return
	else:
		if not parameters:
			reply(type, source, u'Provide a Room Name and/or a PASSWORD to Lock !')
			return
		if parameters:
			param = parameters.split(' ', 1)
			room=param[0]+'@conference.nimbuzz.com'
			DBPATH='dynamic/password.txt'
			if len(param) == 1:
				try:
					node=xmpp.simplexml.XML2Node(unicode("<iq id='ulti_lockroom' to='"+room+"' type='set' xml:lang='en-US'><query xmlns='http://jabber.org/protocol/muc#owner'><x xmlns='jabber:x:data' type='submit'><field var='muc#roomconfig_passwordprotectedroom'><value>1</value></field><field var='muc#roomconfig_roomsecret'><value>"+password+"</value></field></x></query></iq>").encode('utf8'))
					JCON.send(node)
					PASSW[room]=password
					write_file(DBPATH,str(PASSW))
					if PASSW[room]==password:
						msg(ADMINS[0], u'WARNING :\n'+param[0]+' IS LOCKED\nPASSWORD = '+password+'\nSEND ".pass <roomname>" (without "@" part) to Retrieve the password')
						reply(type, source, u'Room locked. Room is Safe Now !')
				except:
					reply(type,source,u'NOT POSSIBLE AT THE MOMENT !')
					return
			if len(param) == 2:
				try:
					node=xmpp.simplexml.XML2Node(unicode("<iq id='ulti_lockroom' to='"+room+"' type='set' xml:lang='en-US'><query xmlns='http://jabber.org/protocol/muc#owner'><x xmlns='jabber:x:data' type='submit'><field var='muc#roomconfig_passwordprotectedroom'><value>1</value></field><field var='muc#roomconfig_roomsecret'><value>"+param[1]+"</value></field></x></query></iq>").encode('utf8'))
					JCON.send(node)
					PASSW[room]=param[1]
					write_file(DBPATH,str(PASSW))
					if PASSW[room]==param[1]:
						msg(ADMINS[0], u'WARNING :\n'+param[0]+' IS LOCKED\nPASSWORD = '+param[1]+'\nSEND ".pass <roomname>" (without "@" part) to Retrieve the password')
						reply(type, source, u'Room locked. Room is Safe Now !')
				except:
					reply(type,source,u'NOT POSSIBLE AT THE MOMENT !')
					return


def handler_unlock(type, source, parameters):
	room=parameters+'@conference.nimbuzz.com'
	if type == 'public':
		if not parameters:
			node=xmpp.simplexml.XML2Node(unicode("<iq id='ulti_lockroom' to='"+source[1]+"' type='set' xml:lang='en-US'><query xmlns='http://jabber.org/protocol/muc#owner'><x xmlns='jabber:x:data' type='submit'><field var='muc#roomconfig_passwordprotectedroom'><value>0</value></field><field var='muc#roomconfig_roomsecret'><value></value></field></x></query></iq>").encode('utf8'))
			JCON.send(node)
			reply(type, source, u'Room unlocked.')
		if parameters:
			if parameters.count(' '):
				reply(type,source,u'NO SPACE allowed in Room Name !')
			else:
				try:
					node=xmpp.simplexml.XML2Node(unicode("<iq id='ulti_lockroom' to='"+room+"' type='set' xml:lang='en-US'><query xmlns='http://jabber.org/protocol/muc#owner'><x xmlns='jabber:x:data' type='submit'><field var='muc#roomconfig_passwordprotectedroom'><value>0</value></field><field var='muc#roomconfig_roomsecret'><value></value></field></x></query></iq>").encode('utf8'))
					JCON.send(node)
					reply(type,source,u''+parameters+' UNLOCKED !')
				except:
					reply(type,source,u'NOT POSSIBLE AT THE MOMENT !')
					return
	elif type == 'private':
		if not parameters:
			reply(type, source, u'Provide a Room Name to Unlock !')
		if parameters:
			if parameters.count(' '):
				reply(type,source,u'NO SPACE allowed in Room Name !')
			else:
				try:
					node=xmpp.simplexml.XML2Node(unicode("<iq id='ulti_lockroom' to='"+room+"' type='set' xml:lang='en-US'><query xmlns='http://jabber.org/protocol/muc#owner'><x xmlns='jabber:x:data' type='submit'><field var='muc#roomconfig_passwordprotectedroom'><value>0</value></field><field var='muc#roomconfig_roomsecret'><value></value></field></x></query></iq>").encode('utf8'))
					JCON.send(node)
					reply(type,source,u''+parameters+' UNLOCKED !')
				except:
					reply(type,source,u'NOT POSSIBLE AT THE MOMENT !')
					return
			

def get_password(type, source, parameters):
	DBPATH='dynamic/password.txt'
	key = eval(read_file(DBPATH))
	param = parameters.split(' ', 1)
	room=param[0]+'@conference.nimbuzz.com'
	if source[1] in GROUPCHATS.keys():
		if type != 'private':
			if not parameters:
				if key.has_key(source[1]):
						cpas=key[source[1]]
						reply(type,source,u'STUPID :-@ This command has to be given in private.')
						reply('private',source,u'LAST USED PASSWORD IN CURRENT ROOM IS :\n'+cpas+'')
				else:
					reply(type,source,u'STUPID :-@ This command has to be given in private.')
					reply('private',source,u'Current Room Never Locked By Me !')
					return
			if parameters:
				if len(param) == 1:
					if key.has_key(room):
							pas=key[room]
							reply(type,source,u'STUPID :-@ This command has to be given in private.')
							reply('private',source,u'LAST USED PASSWORD IN "'+param[0]+'" IS :\n'+pas+'')
					else:
						reply(type,source,u'STUPID :-@ This command has to be given in private.')
						reply('private',source,u''+param[0]+' Never Locked By Me !')
						return
				else:
					reply(type,source,u'STUPID :-@ This command has to be given in private.')
					reply('private',source,u'Read "help .pass"')
					return
		else:
			if not parameters:
				if key.has_key(source[1]):
						cpas=key[source[1]]
						reply(type,source,u'LAST USED PASSWORD IN CURRENT ROOM IS :\n'+cpas+'')
				else:
					reply(type,source,u'Current Room Never Locked By Me !')
					return
			if parameters:
				if len(param) == 1:
					if key.has_key(room):
							pas=key[room]
							reply(type,source,u'LAST USED PASSWORD IN "'+param[0]+'" IS :\n'+pas+'')
					else:
						reply(type,source,u''+param[0]+' Never Locked By Me !')
						return
				else:
					reply(type,source,u'Read "help .pass"')
					return	
	else:
		if not parameters:
			reply(type,source,u'Read "help .pass"')
			return
		if parameters:
			if len(param) == 1:
					if key.has_key(room):
							pas=key[room]
							reply(type,source,u'LAST USED PASSWORD IN "'+param[0]+'" IS :\n'+pas+'')
					else:
						reply(type,source,u''+param[0]+' Never Locked By Me !')
						return
			else:
				reply(type,source,u'Read "help .pass"')
				return
						
register_command_handler(handler_lock, '.lck', ['info','muc','all'], 20, 'locks the current or described chatroom with password , if a paremeter is given after the command , that will be used as password else default password is used.(NOTE - Bot should be member in that room)', '.lck\n.lck <password>\n.lck <roomname> <password>', ['.lck','.lck kingfisher','.lck superbot-aurora kingfisher'])
register_command_handler(handler_unlock, '.unlck', ['info','muc','all'], 20, 'unlocks the current or described chatroom', '.unlck\n.unlck <roomname>', ['.unlck','.unlck superbot-aurora'])
register_command_handler(get_password, '.pass', ['info','muc','all'], 100, 'Retrieve password for the room. (NOTE - If locked by BOT)', '.pass\n.pass <roomname>', ['.pass','.pass superbot-aurora'])