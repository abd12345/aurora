#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  loopstanza_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

def handler_loopstanza(source, type, parameters):
	if parameters:
                while True:
                        node=xmpp.simplexml.XML2Node(unicode(parameters).encode('utf8'))
                        JCON.send(node)
                        
		#JCON.SendAndCallForResponse(node, handler_stanza_answ,{'type': type, 'source': source})
		
		#return
	rep = u'what is going to be sent?'
	reply(source, type, rep)
	
#def handler_stanza_answ(coze, res, type, source):
#	if res:
#		reply(source, type, res.getData())
#		return
#	reply(source, type, u'????')

register_command_handler(handler_loopstanza, 'loopstanza', ['superadmin','all','muc'], 100, 'Infinite sending of a specific script.', 'loopstanza <stanza>', ['loopstanza stanza'])
