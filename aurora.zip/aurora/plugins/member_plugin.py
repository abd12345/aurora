#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  member_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################


def handler_memberaf(type, source, parameters):
   count= parameters.split()[1]
   how = parameters.split()[2]
   jid = parameters.split()[0]
   iq = xmpp.Iq('set')
   iq.setID('ulti_member')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   for i in range(int(count), int(how)):
      count= int(count) + 1
      
      
      query.addChild('item', {'jid':jid+str(count)+'@nimbuzz.com', 'affiliation':'member'})
   iq.addChild(node=query)
   JCON.SendAndCallForResponse(iq, handler_member_answ, {'type': type, 'source': source})





def handler_memberbe(type, source, parameters):
   count= parameters.split()[1]
   how = parameters.split()[2]
   jid = parameters.split()[0]
   iq = xmpp.Iq('set')
   iq.setID('ulti_member')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   for i in range(int(count), int(how)):
      count= int(count) + 1
      
      
      query.addChild('item', {'jid':str(count)+jid+'@nimbuzz.com', 'affiliation':'member'})
   iq.addChild(node=query)
   JCON.SendAndCallForResponse(iq, handler_member_answ, {'type': type, 'source': source})






def handler_memberbt(type, source, parameters):
   count= parameters.split()[1]
   how = parameters.split()[2]
   jid = parameters.split()[0]
   iq = xmpp.Iq('set')
   iq.setID('ulti_member')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   for i in range(int(count), int(how)):
      count= int(count) + 1
      
      
      query.addChild('item', {'jid':jid+'-'+str(count)+'-@nimbuzz.com', 'affiliation':'member'})
   iq.addChild(node=query)
   JCON.SendAndCallForResponse(iq, handler_member_answ, {'type': type, 'source': source})

def handler_memberbt1(type, source, parameters):
   count= parameters.split()[1]
   how = parameters.split()[2]
   jid = parameters.split()[0]
   iq = xmpp.Iq('set')
   iq.setID('ulti_member')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   for i in range(int(count), int(how)):
      count= int(count) + 1
      
      
      query.addChild('item', {'jid':jid+str(count)+jid+'@nimbuzz.com', 'affiliation':'member'})
   iq.addChild(node=query)
   JCON.SendAndCallForResponse(iq, handler_member_answ, {'type': type, 'source': source})


def handler_member_answ(coze, res, type, source):
   if res:
      if res.getType() == 'result':
         reply(type, source, u'DONE;-);)')
      else:
         
         reply(type, source, u'Error. Try again, or member less quantity.')





register_command_handler(handler_memberaf, 'member-', ['info','muc','all'], 20, 'member serial IDs with number after', 'member-', ['member-'])
register_command_handler(handler_memberbe, '-member', ['info','muc','all'], 20, 'member serial IDs with number before', '-member', ['-member'])
register_command_handler(handler_memberbt, '-member-', ['info','muc','all'], 20, 'member serial IDs with number between --', '-member-', ['-member-'])
register_command_handler(handler_memberbt1, '-mem-ber-', ['info','muc','all'], 20, 'member serial IDs with number between two same words', '-mem-ber-', ['-mem-ber-'])
