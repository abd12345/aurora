#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  more_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################


def handler_more(type, source, parameters):
	if type!='private':
		if source[1] in GCHCFGS.keys() and GCHCFGS[source[1]]['more']==1:
			if LAST['gch'][source[1]]['msg']:
				reply(type,source, LAST['gch'][source[1]]['msg'])
	else:
		reply(type,source, u'a sense?')
			
def handler_more_outmsg(target, body, obody):
	if target in GCHCFGS.keys() and GCHCFGS[target]['more']==1:
		if hash(obody)!=LAST['gch'][target]['msg']:
			if len(obody)>1000:
				LAST['gch'][target]['msg']=obody[1000:]

def init_more(gch):
	if not 'more' in GCHCFGS[gch]:
		GCHCFGS[gch]['more']=1
	if GCHCFGS[gch]['more']:
		LAST['gch'][gch]['msg']=''
			

register_command_handler(handler_more, 'more', ['muc','all'], 0, 'Finishes poll and shows result.', 'more', ['more'])			
register_outgoing_message_handler(handler_more_outmsg)
register_stage1_init(init_more)
