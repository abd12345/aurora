#--===auroraplugin===--
# -*- coding: utf-8 -*-
#  aurora plugin
#  note_plugin.py
#  coded by kf (kforkingfisher@/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########

import os

def handler_note_add(type, source, parameters):
    if check_file('notepad','notepad.txt'):
      files = 'dynamic/notepad/notepad.txt'
      fp = open(files, 'r')
      note = eval(fp.read())
      fp.close()
      if parameters:
        if note.has_key(get_true_jid(source[1]+'/'+source[2])):
            if os.path.isfile('dynamic/notepad/limit.cfg'):
              lf = 'dynamic/notepad/limit.cfg'
              lr = open(lf, 'r')
              limit = eval(lr.read())
              lr.close()
              if len(note[get_true_jid(source[1]+'/'+source[2])])>=limit:
                if limit==0:
                  reply(type, source, u'Writing in a notebook temporarily disabled by the administrator bot')
                  return
                reply(type, source, u'The maximum number of stored records - '+str(limit))
              else:
                dates = time.strftime('%H:%M:%S %d.%m.%y\n')
                note[get_true_jid(source[1]+'/'+source[2])].append(dates+parameters)
                write_file(files, str(note))
                reply(type, source, u'recorded')
            else:
              lf = 'dynamic/notepad/limit.cfg'
              write_file(lf, str(25))
              lr = open(lf, 'r')
              limit = eval(lr.read())
              lr.close()
              if len(note[get_true_jid(source[1]+'/'+source[2])])>=limit:
                if limit==0:
                  reply(type, source, u'Writing in a notebook temporarily disabled by the administrator bot')
                  return
                reply(type, source, u'The maximum number of stored records - '+str(limit))
              else:
                dates = time.strftime('%H:%M:%S %d.%m.%y\n')
                note[get_true_jid(source[1]+'/'+source[2])].append(dates+parameters)
                write_file(files, str(note))
                reply(type, source, u'recorded')
        else:
          if os.path.isfile('dynamic/notepad/limit.cfg'):
            lf = 'dynamic/notepad/limit.cfg'
            lr = open(lf, 'r')
            limit = eval(lr.read())
            lr.close()
            note[get_true_jid(source[1]+'/'+source[2])] = []
            dates = time.strftime('%H:%M:%S %d.%m.%y\n')
            if limit==0:
              reply(type, source, u'Writing in a notebook temporarily disabled by the administrator bot')
              return
            note[get_true_jid(source[1]+'/'+source[2])].append(dates+parameters)
            write_file(files, str(note))
            reply(type, source, u'recorded')
          else:
            lf = 'dynamic/notepad/limit.cfg'
            write_file(lf, str(25))
            note[get_true_jid(source[1]+'/'+source[2])] = []
            dates = time.strftime('%H:%M:%S %d.%m.%y\n')
            note[get_true_jid(source[1]+'/'+source[2])].append(dates+parameters)
            write_file(files, str(note))
            reply(type, source, u'recorded')
      else:
        reply(type, source, u'What to write down?')
    else:
      reply(type, source, u'Errors in the notepad! \ Urgently contact the admin bot')
      
def handler_note_del(type, source, parameters):
  if check_file('notepad','notepad.txt'):
    files = 'dynamic/notepad/notepad.txt'
    fp = open(files, 'r')
    note = eval(fp.read())
    fp.close()
    if not parameters:
      reply(type, source, u'I do not find their records')
      return
    if note.has_key(get_true_jid(source[1]+'/'+source[2])):
      try:
        parameters = int(parameters) - int(1)
        del note[get_true_jid(source[1]+'/'+source[2])][parameters]
        write_file(files, str(note))
        reply(type, source, u'removed')
      except:
        reply(type, source, u'It did not work')
    else:
      reply(type, source, u'I do not find their records')
  else:
    reply(type, source, u'Base notepad is not created. Contact the admin bot')
    
def handler_note_show(type, source, parameters):
      if check_file('notepad','notepad.txt'):
        files = 'dynamic/notepad/notepad.txt'
        fp = open(files, 'r')
        note = eval(fp.read())
        fp.close()
        if not parameters:
          if note.has_key(get_true_jid(source[1]+'/'+source[2])):
            rep = ''
            for a, b in enumerate(note[get_true_jid(source[1]+'/'+source[2])]):
              rep+=str(a+1)+') '+b+'\n'
            if str(note[get_true_jid(source[1]+'/'+source[2])]) == '[]':
              reply(type, source, u'I do not find their records')
              return
            reply(type, source, '\n'+rep)
          else:
            reply(type, source, u'I do not find their records')
            return
        params = parameters.split(' ', 1)
        if len(params) == 1:
              if params[0]==u'clear':
                if note.has_key(get_true_jid(source[1]+'/'+source[2])):
                  del note[get_true_jid(source[1]+'/'+source[2])]
                  write_file(files, str(note))
                  reply(type, source, u'Clear the list of their records')
                else:
                  reply(type, source, u'I do not find their records')
              if params[0]==u'limit':
                if os.path.isfile('dynamic/notepad/limit.cfg'):
                  lf = 'dynamic/notepad/limit.cfg'
                  lr = open(lf, 'r')
                  lt = eval(lr.read())
                  lr.close()
                  if str(lt)=='0':
                    reply(type, source, u'Writing in a notebook temporarily disabled by the administrator bot')
                    return
                  reply(type, source, u'A limit of records - '+str(lt))
                else:
                  lf = 'dynamic/notepad/limit.cfg'
                  write_file(lf,str(25))
                  time.sleep(0.1)
                  lr = open(lf, 'r')
                  lt = eval(lr.read())
                  lr.close()
                  reply(type, source, u'A limit of records - '+str(lt))
        elif len(params) == 2:
            if params[0]==u'limit':
              if user_level(source[1]+'/'+source[2], source[1])==100:
                try:
                  if int(params[1])+int(1):
                    write_file('dynamic/notepad/limit.cfg',str(params[1]))
                    if params[1]==u'0':
                      reply(type, source, u'Writing in a notebook is off')
                      return
                    reply(type, source, u'A limit of records - '+str(params[1]))
                except ValueError:
                  reply(type, source, u'Where have you seen these numbers?')
              else:
                reply(type, source, u'Changing the limit is only a bot admins')
            else:
              if note.has_key(get_true_jid(source[1]+'/'+source[2])):
                rep = ''
                for a, b in enumerate(note[get_true_jid(source[1]+'/'+source[2])]):
                  rep+=str(a+1)+') '+b+'\n'
                if str(note[get_true_jid(source[1]+'/'+source[2])]) == '[]':
                  reply(type, source, u'I do not find their records')
                  return
                reply(type, source, '\n'+rep)
              else:
                reply(type, source, u'I do not find their records')
                return
      else:
        reply(type, source, u'Base notepad is not created. contact the admin bot')
        
        
register_command_handler(handler_note_add, 'note_add', ['all','muc'], 10, 'Your personal notebook. All of your personal account linked to your JID, available in any conference where the boat sits. \ N # adds an entry to your personal notebook', 'note_add <something>', ['note_add must add kforkingfisher@nimbuzz.com \nby kingfisher'])
register_command_handler(handler_note_del, 'note_del', ['all','muc'], 10, 'Your personal notebook. All of your personal account linked to your JID, available in any conference where the boat sits. \ N # Deletes the entry from your personal notebook', 'note_del <record number>', ['note_del 2\nby kingfisher'])
register_command_handler(handler_note_show, 'note', ['all','muc'], 10, 'Your personal notebook. All of your personal account linked to your JID, available in any conference where the boat sits. \ N # without the - all records from your personal notebook \ nnote clear - clears the entire list of your recordings \ nnote limit - View installed Admin limit on the number of of records \ nnote limit <number> - Set the limit of records available bot admins', '.note\nnote <parameters> <parameters>', ['.note\nnote clear\nnote limit\nnote limit 15\nby kingfisher'])