#--===auroraplugin===--
# -*- coding: utf-8 -*-
#  aurora plugin
#  autoban_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################


bl=eval(read_file('dynamic/bl.txt'))
        
def handler_banafd(groupchat, nick, reason):
   
 
   iq = xmpp.Iq('set')
   iq.setID('ulti_ban')
   iq.setTo(groupchat)
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#admin')
   ban=query.addChild('item', {'jid':nick+'@nimbuzz.com', 'affiliation':'outcast'})
   iq.addChild(node=query)
   JCON.send(iq)


def ban_join(groupchat, nick, aff, role):
   jid=get_true_jid(groupchat+'/'+nick)
   if nick in GROUPCHATS[groupchat] and user_level(groupchat+'/'+nick,groupchat)<11:

      for x in bl:
         if nick.count(x):
            handler_banafd(groupchat, nick, u'autobanned...')
	

def ban_jid(type, source, parameters):
   reply(type, source, 'warning !!!...autoban is active !!')
   if check_file_ex('dynamic/bl.txt'):
      data = eval(read_file('dynamic/bl.txt'))
   
   
      write_file('dynamic/bl.txt', str(parameters))
      return
   
   
   

def check_file_ex(gch='',file=''):
	pth,pthf='',''
	if gch:
		pthf=gch+file
		pth=gch
	else:
		pthf=gch+file
		pth='gch'
	if os.path.exists(pthf):
		return 1
	else:
		try:
			if not os.path.exists(pth):
				os.mkdir(pth,0755)
			if os.access(pthf, os.F_OK):
				fp = file(pthf, 'w')
			else:
				fp = open(pthf, 'w')
			fp.write('{}')
			fp.close()
			return 1
		except:
			return 0






register_join_handler(ban_join)
register_command_handler(ban_jid, 'autoban', ['info','muc','all'], 100, 'Auto ban any JID that has a specific word (located in dynamic/bl.txt) upon entrance.', 'autoban <word>', ['autoban fuck'])