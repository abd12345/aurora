#--===auroraplugin===--
# -*- coding: utf-8 -*-
#  aurora plugin
#  quote_plugin.py
#  Edited by kf (kforkingfisher@/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########

import urllib

QUOTE_FILE = 'static/quotes.txt'

def handler_quote_quote(type, source, parameters):
	reply = random.choice(open(QUOTE_FILE, 'r').readlines()).strip()
	smsg(type, source, reply)


register_command_handler(handler_quote_quote, '!quote', ['fun','new','all'], 0, 'Gives a random quote.', '!quote', ['!quote'])
