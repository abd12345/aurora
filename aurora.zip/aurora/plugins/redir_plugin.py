#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  redir_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#  just change room name & username
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################


redir = ''
roomname = 'bangladeshi-friends-adda'
username = 'abd~ksa'

def handler_redir(type, source, parameters):
        global redir
        global roomname
        global username
        if parameters == 'on':
                 redir = '1'
                 reply(type, source, 'Messages redirect from room '+roomname+' to the user '+username+' has been enabled.')
        elif parameters == 'off':
                redir = '0'
                reply(type, source, 'Messages redirect from room '+roomname+' to the user '+username+' has been disabled.')

def redirect_msg(type, source, body):
        global roomname
        global username
        if type == 'public' and source[1] == roomname+'@conference.nimbuzz.com':
                msg(username+'@nimbuzz.com', source[2]+'> '+body)

def handler_redirect_message(type, source, body):
        global redir
        global roomname
	if type == 'public' and redir == '1':
	#	if not COMMANDS.has_key(string.split(body)[0]):
		redirect_msg(type, source, body)
	#elif type == 'private':
	#	if not COMMANDS.has_key(string.split(body)[0]):
	#		redirect_msg(type, source, body)

def handler_send_msg(type, source, parameters):
	if not parameters:
		reply(type, source, u'message?')
		return
	msg(roomname+'@conference.nimbuzz.com', parameters)

register_command_handler(handler_send_msg, 'msg', ['admin','muc','all'], 40, 'Send a message via the bot to the room.', 'msg <room jid> <message>', [''])
register_message_handler(handler_redirect_message)
register_command_handler(handler_redir, 'redir', ['admin','muc','all'], 40, 'Enable/Disable Message redirect from roomname to username (names can be edited in redir plugin.)', 'redir', ['redir'])
