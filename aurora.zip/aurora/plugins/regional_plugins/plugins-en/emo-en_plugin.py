#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  emo-en_plugin.py
#  coded by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

def emo_join(groupchat, nick, aff, role):
	DBPATH='dynamic/'+groupchat+'/config.cfg'
	if nick == DEFAULT_NICK:
	   if GCHCFGS[groupchat].has_key('emo'):
	           return
	   else:
	           GCHCFGS[groupchat]['emo']=1
		   write_file(DBPATH,str(GCHCFGS[groupchat]))

        
def handler_emo(type, source, parameters):
	if type == 'public':
	  if GCHCFGS[source[1]].has_key('emo'):
		if GCHCFGS[source[1]]['emo']==1:
			if parameters == ':)':
				replies = ['nice smile :) ', 'ur smile is like my gfs smile :$:D', ' wht a beautiful smile :P :O']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-)':
				replies = ['nice smile :) ', 'ur smile is like my gfs smile :$:D', ' wht a beautiful smile :P :O']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ';)':
				replies = ['hey dnt wink here :|', 'if u do this again i will kick u :|', 'hey dnt do this here is t a decent room :O:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ';-)':
				replies = ['hey dnt wink here :|', 'if u do this again i will kick u :|', 'hey dnt do this here is t a decent room :O:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':D':
				replies = ['dont shw ur yellow teeths here :D', 'cn u tell me why r u laughing:O:D', ' go nd brush ur teeth first :D :|', 'if u dnt stop laughinh i will break all ur teaths I-):D', ' laughing increases blood i think :O :|', ' hv i tell u any type of joke :S']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-D':
				replies = ['dont shw ur yellow teeths here :D', 'cn u tell me why r u laughing:O:D', ' go nd brush ur teeth first :D :|', 'if u dnt stop laughinh i will break all ur teaths I-):D', ' laughing increases blood i think :O :|', ' hv i tell u any type of joke :S']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':d':
				replies = ['dont shw ur yellow teeths here :D', 'cn u tell me why r u laughing:O:D', ' go nd brush ur teeth first :D :|', 'if u dnt stop laughinh i will break all ur teaths I-):D', ' laughing increases blood i think :O :|', ' hv i tell u any type of joke :S']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':-d':
				replies = ['dont shw ur yellow teeths here :D', 'cn u tell me why r u laughing:O:D', ' go nd brush ur teeth first :D :|', 'if u dnt stop laughinh i will break all ur teaths I-):D', ' laughing increases blood i think :O :|', ' hv i tell u any type of joke :S']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':(':
				replies = ['i think his gf dump him :|:D', 'why r u sad dear :( :|', ' don be sad please (f) ;)']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-(':
				replies = ['i think his gf dump him :|:D', 'why r u sad dear :( :|', ' don be sad please (f) ;)']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':P':
				replies = ['i also cn do this see :P:P:P:P :| :D', ':P:P:P:P:p:P i dnt like this:@', ' only small kids do this :P :|:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-P':
				replies = ['i also cn do this see :P:P:P:P :| :D', ':P:P:P:P:p:P i dnt like this:@', ' only small kids do this :P :|:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':p':
				replies = ['i also cn do this see :P:P:P:P :| :D', ':P:P:P:P:p:P i dnt like this:@', ' only small kids do this :P :|:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-p':
				replies = ['i also cn do this see :P:P:P:P :| :D', ':P:P:P:P:p:P i dnt like this:@', ' only small kids do this :P :|:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':@':
				replies = ['i m also angry:@:D', ':-SS sm 1 same me :|', ' u r dangerous :-SS :P :D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-@':
				replies = ['i m also angry:@:D', ':-SS sm 1 same me :|', ' u r dangerous :-SS :P :D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':*':
				replies = ['do all this in pvt :| :D', 'its a decent room :|']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-*':
				replies = ['do all this in pvt :| :D', 'its a decent room :|']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':S':
				replies = ['why confused tell me i cn hlp u:d', 'cn i hlp u ??:-s:s:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-S':
				replies = ['why confused tell me i cn hlp u:d', 'cn i hlp u ??:-s:s:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':s':
				replies = ['why confused tell me i cn hlp u:d', 'cn i hlp u ??:-s:s:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-s':
				replies = ['why confused tell me i cn hlp u:d', 'cn i hlp u ??:-s:s:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '>D':
				replies = ['8[]ghost :D:-ss ', '>D>D>D>D>D>D>D:D', ' is this ur real face ?:o:p:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '>d':
				replies = ['8[]ghost :D:-ss ', '>D>D>D>D>D>D>D:D', ' is this ur real face ?:o:p:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(6)':
				replies = ['8[]ghost :D:-ss ', '>D>D>D>D>D>D>D:D', ' is this ur real face ?:o:p:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':-&':
				replies = ['go and wash ur face :D ', 'plz wash ur face with face wash :d:p', ' r u hulk he has greek body :o :|']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '@};-':
				replies = ['is this for me ?:$:d:d ', 'thnx vry much for this flower:):d:p']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(f)':
				replies = ['is this for me ?:$:d:d ', 'thnx vry much for this flower:):d:p']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == 'I-)':
				replies = ['u need rest go to ur bed:P:d ', 'go take a nap dear :):d:p']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-ss':
				replies = ['why r u afraid i m here:):| ', 'why so afraid :S', ' this room needs to be clean:D:D ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-SS':
				replies = ['why r u afraid i m here:):| ', 'why so afraid :S', ' this room needs to be clean:D:D ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '8[]':
				replies = ['shut ur mouth dear:D :| :D ', 'i think u r hungry :p:d']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == 'O:-)':
				replies = ['i first time saw an angel :D:p ', 'o fake angel here :Oo:-):d:d', ' o:-)cn u give me a wish? :(']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == 'o:-)':
				replies = ['i first time saw an angel :D:p ', 'o fake angel here :Oo:-):d:d', ' o:-)cn u give me a wish? :(']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == '<3':
				replies = ['<3:O romantic people:O:S:D ', '<3 is this pigeons heart :O:D:|']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(U)':
				replies = [' u need glu? to stick this? :d:d', '(u)who done this to u :(:(']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(u)':
				replies = [' u need glu? to stick this? :d:d', '(u)who done this to u :(:(']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':|':
				replies = [':| i didnt like silence:p ', 'wht happened?:O:| ', 'say smthing dear:)']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-|':
				replies = [':| i didnt like silence:p ', 'wht happened?:O:| ', 'say smthing dear:)']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(:|':
				replies = ['take this cup of tea|_|:p ', ':)dn sleep here go to ur bed :P ', ' u want coffy ??']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':#':
				replies = ['nw m also :-#', 'cn u tell me whts the matter:-# ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-#':
				replies = ['nw m also :-#', 'cn u tell me whts the matter:-# ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':O':
				replies = [':owht happend:d:) ', ':o wht is so surprising :O:O:O ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':-O':
				replies = [':owht happend:d:) ', ':o wht is so surprising :O:O:O ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':o':
				replies = [':owht happend:d:) ', ':o wht is so surprising :O:O:O ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-o':
				replies = [':owht happend:d:) ', ':o wht is so surprising :O:O:O ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':$':
				replies = [':$ what a lovely face:p:d ', 'u r so shy :$ :D', ' wht a lovely face come on give me a kiss :* :P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-$':
				replies = [':$ what a lovely face:p:d ', 'u r so shy :$ :D', ' wht a lovely face come on give me a kiss :* :P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)			
	elif type == 'private':
			if parameters == ':)':
				replies = ['nice smile :) ', 'ur smile is like my gfs smile :$:D', ' wht a beautiful smile :P :O']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-)':
				replies = ['nice smile :) ', 'ur smile is like my gfs smile :$:D', ' wht a beautiful smile :P :O']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ';)':
				replies = ['hey dnt wink here :|', 'if u do this again i will kick u :|', 'hey dnt do this here is t a decent room :O:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ';-)':
				replies = ['hey dnt wink here :|', 'if u do this again i will kick u :|', 'hey dnt do this here is t a decent room :O:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':D':
				replies = ['dont shw ur yellow teeths here :D', 'cn u tell me why r u laughing:O:D', ' go nd brush ur teeth first :D :|', 'if u dnt stop laughinh i will break all ur teaths I-):D', ' laughing increases blood i think :O :|', ' hv i tell u any type of joke :S']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-D':
				replies = ['dont shw ur yellow teeths here :D', 'cn u tell me why r u laughing:O:D', ' go nd brush ur teeth first :D :|', 'if u dnt stop laughinh i will break all ur teaths I-):D', ' laughing increases blood i think :O :|', ' hv i tell u any type of joke :S']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':d':
				replies = ['dont shw ur yellow teeths here :D', 'cn u tell me why r u laughing:O:D', ' go nd brush ur teeth first :D :|', 'if u dnt stop laughinh i will break all ur teaths I-):D', ' laughing increases blood i think :O :|', ' hv i tell u any type of joke :S']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':-d':
				replies = ['dont shw ur yellow teeths here :D', 'cn u tell me why r u laughing:O:D', ' go nd brush ur teeth first :D :|', 'if u dnt stop laughinh i will break all ur teaths I-):D', ' laughing increases blood i think :O :|', ' hv i tell u any type of joke :S']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':(':
				replies = ['i think his gf dump him :|:D', 'why r u sad dear :( :|', ' don be sad please (f) ;)']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-(':
				replies = ['i think his gf dump him :|:D', 'why r u sad dear :( :|', ' don be sad please (f) ;)']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':P':
				replies = ['i also cn do this see :P:P:P:P :| :D', ':P:P:P:P:p:P i dnt like this:@', ' only small kids do this :P :|:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-P':
				replies = ['i also cn do this see :P:P:P:P :| :D', ':P:P:P:P:p:P i dnt like this:@', ' only small kids do this :P :|:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':p':
				replies = ['i also cn do this see :P:P:P:P :| :D', ':P:P:P:P:p:P i dnt like this:@', ' only small kids do this :P :|:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-p':
				replies = ['i also cn do this see :P:P:P:P :| :D', ':P:P:P:P:p:P i dnt like this:@', ' only small kids do this :P :|:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':@':
				replies = ['i m also angry:@:D', ':-SS sm 1 same me :|', ' u r dangerous :-SS :P :D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-@':
				replies = ['i m also angry:@:D', ':-SS sm 1 same me :|', ' u r dangerous :-SS :P :D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':*':
				replies = ['do all this in pvt :| :D', 'its a decent room :|']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-*':
				replies = ['do all this in pvt :| :D', 'its a decent room :|']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':S':
				replies = ['why confused tell me i cn hlp u:d', 'cn i hlp u ??:-s:s:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-S':
				replies = ['why confused tell me i cn hlp u:d', 'cn i hlp u ??:-s:s:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':s':
				replies = ['why confused tell me i cn hlp u:d', 'cn i hlp u ??:-s:s:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-s':
				replies = ['why confused tell me i cn hlp u:d', 'cn i hlp u ??:-s:s:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '>D':
				replies = ['8[]ghost :D:-ss ', '>D>D>D>D>D>D>D:D', ' is this ur real face ?:o:p:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '>d':
				replies = ['8[]ghost :D:-ss ', '>D>D>D>D>D>D>D:D', ' is this ur real face ?:o:p:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(6)':
				replies = ['8[]ghost :D:-ss ', '>D>D>D>D>D>D>D:D', ' is this ur real face ?:o:p:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':-&':
				replies = ['go and wash ur face :D ', 'plz wash ur face with face wash :d:p', ' r u hulk he has greek body :o :|']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '@};-':
				replies = ['is this for me ?:$:d:d ', 'thnx vry much for this flower:):d:p']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(f)':
				replies = ['is this for me ?:$:d:d ', 'thnx vry much for this flower:):d:p']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == 'I-)':
				replies = ['u need rest go to ur bed:P:d ', 'go take a nap dear :):d:p']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-ss':
				replies = ['why r u afraid i m here:):| ', 'why so afraid :S', ' this room needs to be clean:D:D ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-SS':
				replies = ['why r u afraid i m here:):| ', 'why so afraid :S', ' this room needs to be clean:D:D ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '8[]':
				replies = ['shut ur mouth dear:D :| :D ', 'i think u r hungry :p:d']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == 'O:-)':
				replies = ['i first time saw an angel :D:p ', 'o fake angel here :Oo:-):d:d', ' o:-)cn u give me a wish? :(']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == 'o:-)':
				replies = ['i first time saw an angel :D:p ', 'o fake angel here :Oo:-):d:d', ' o:-)cn u give me a wish? :(']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == '<3':
				replies = ['<3:O romantic people:O:S:D ', '<3 is this pigeons heart :O:D:|']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(U)':
				replies = [' u need glu? to stick this? :d:d', '(u)who done this to u :(:(']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(u)':
				replies = [' u need glu? to stick this? :d:d', '(u)who done this to u :(:(']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':|':
				replies = [':| i didnt like silence:p ', 'wht happened?:O:| ', 'say smthing dear:)']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-|':
				replies = [':| i didnt like silence:p ', 'wht happened?:O:| ', 'say smthing dear:)']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(:|':
				replies = ['take this cup of tea|_|:p ', ':)dn sleep here go to ur bed :P ', ' u want coffy ??']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':#':
				replies = ['nw m also :-#', 'cn u tell me whts the matter:-# ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-#':
				replies = ['nw m also :-#', 'cn u tell me whts the matter:-# ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':O':
				replies = [':owht happend:d:) ', ':o wht is so surprising :O:O:O ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':-O':
				replies = [':owht happend:d:) ', ':o wht is so surprising :O:O:O ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':o':
				replies = [':owht happend:d:) ', ':o wht is so surprising :O:O:O ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-o':
				replies = [':owht happend:d:) ', ':o wht is so surprising :O:O:O ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':$':
				replies = [':$ what a lovely face:p:d ', 'u r so shy :$ :D', ' wht a lovely face come on give me a kiss :* :P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-$':
				replies = [':$ what a lovely face:p:d ', 'u r so shy :$ :D', ' wht a lovely face come on give me a kiss :* :P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
def handler_emo_onoff(type, source, parameters):
	if not source[1] in GROUPCHATS:
		reply(type, source, u'This command only possible in the conference')
		return
	if parameters:
		try:
			parameters=int(parameters.strip())
		except:
			reply(type,source,u'read "help emo"')
			return		
		DBPATH='dynamic/'+source[1]+'/config.cfg'
		if parameters==1:
			if GCHCFGS[source[1]]['emo']==1:
				reply(type,source,u'Emo Response Already Enabled !')
				return
			else:
				GCHCFGS[source[1]]['emo']=1
				reply(type,source,u'Emo Response Enabled !')
				return
		else:
			GCHCFGS[source[1]]['emo']=0
			reply(type,source,u'Emo Response Disabled !')
		write_file(DBPATH,str(GCHCFGS[source[1]]))
	else:
		ison=GCHCFGS[source[1]]['emo']
		if ison==1:
			reply(type,source,u'Emo Response is Enabled here !')
		else:
			reply(type,source,u'Emo Response is Disabled here !')

register_join_handler(emo_join)
register_message_handler(handler_emo)
register_command_handler(handler_emo_onoff, 'em', ['admin','muc','all'], 100, 'Off (0) On (1) activate or de-activate Emo response, without parameter shows current status', 'emo [conf] [1|0]', ['emo 1','emo 0','emo'])
