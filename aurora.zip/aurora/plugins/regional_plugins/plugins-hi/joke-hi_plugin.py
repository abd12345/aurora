#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  joke-en_plugin.py
#  coded by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

def handler_joke(type, source, parameters):
	jokes = []
	jokes.extend(eval(read_file('static/jokes-hi.txt'))['jokes'])
	balas = random.choice(jokes)
	if not parameters:
		reply(type, source, balas)
	if parameters:
		reply(type, source, balas)


register_command_handler(handler_joke, 'joke', ['new'], 0, '', '', [''])
register_command_handler(handler_joke, 'jokes', ['new'], 0, '', '', [''])
register_command_handler(handler_joke, 'chutkulla', ['new'], 0, '', '', [''])
register_command_handler(handler_joke, 'chutkulle', ['new'], 0, '', '', [''])
register_command_handler(handler_joke, 'chutkula', ['new'], 0, '', '', [''])
register_command_handler(handler_joke, 'chutkule', ['new'], 0, '', '', [''])
