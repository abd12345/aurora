#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  antikick-en_plugin.py
#  coded by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################


def emptyroom():
	if LOCAL_CONFIG['new'] == 'no':
		msg(ADMINS[0], u'Anti restart activated !')

def keepalive():
	ping=xmpp.simplexml.XML2Node(unicode("<iq type='get' id='ping' to='nimbuzz.com'><ping xmlns='urn:xmpp:ping'/></iq>").encode('utf8'))
	JCON.send(ping)

def keepalive_start():
	while True:
		time.sleep(58)
		keepalive()
        
keepalive_th = threading.Thread(target=keepalive_start)
keepalive_th.setDaemon(True)
keepalive_th.start()
				
def antikick_join(groupchat, nick, aff, role):
	DBPATH='dynamic/'+groupchat+'/config.cfg'
	if nick == DEFAULT_NICK:
		if GCHCFGS[groupchat].has_key('antikick'):
			return
		else:
			GCHCFGS[groupchat]['antikick']=1
		write_file(DBPATH,str(GCHCFGS[groupchat]))
		threading.Timer(600,handler_antikick,(groupchat,)).start()
	   
def antikick_leave(groupchat, nick, reason, scode):
	if nick == 'admin':
		msg(groupchat, u'Aurora-Bot By Kingfisher !!')

def antikick_starter(gch):
	if 'antikick' in GCHCFGS[gch]:
		threading.Timer(600,handler_antikick,(gch,)).start()

def handler_antikick(gch):
	if GCHCFGS[gch]['antikick']==1:
		while True:
			if GCHCFGS[gch]['antikick']==1:
				if GROUPCHATS.has_key(gch):
					anti=[]
					anti.extend(eval(read_file('static/antikick-en.txt'))['antikick'])
					if random.randrange(0,30) == random.randrange(0,30):
						rep = 'Aurora-Bot By Kingfisher !!'
					else:
						rep = random.choice(anti)
					msg(gch, rep)
			time.sleep(600.0)
    
def handler_antikick_onoff(type, source, parameters):
	if not source[1] in GROUPCHATS:
		reply(type, source, u'This command only possible in the conference')
		return
	if parameters:
		try:
			parameters=int(parameters.strip())
		except:
			reply(type,source,u'Read "help antikick"')
			return		
		DBPATH='dynamic/'+source[1]+'/config.cfg'
		if parameters==1:
			if GCHCFGS[source[1]]['antikick']==1:
				reply(type,source,u'Antikick is Already Enabled !')
				return
			else:
				GCHCFGS[source[1]]['antikick']=1
				reply(type,source,u'Antikick Enabled !')
				time.sleep(12.0)
				pass
		else:
			GCHCFGS[source[1]]['antikick']=0
			reply(type,source,u'Antikick Disabled')
			msg(ADMINS[0], u'NOTIFICATION :\nAntikick Disabled in '+source[1]+'\nActivate it, to avoid Autokick')
		write_file(DBPATH,str(GCHCFGS[source[1]]))
		if GCHCFGS[source[1]]['antikick']==1:
			gch = source[1]
			time.sleep(250.0)
			handler_antikick(gch)
	else:
		ison=GCHCFGS[source[1]]['antikick']
		if ison==1:
			reply(type,source,u'Antikick is Enabled here')
		else:
			reply(type,source,u'Antikick is Disabled here')


register_stage2_init(emptyroom)
register_join_handler(antikick_join)
register_leave_handler(antikick_leave)
register_stage1_init(antikick_starter)
register_command_handler(handler_antikick_onoff, 'antikick', ['admin','muc','all'], 30, 'Off (0) On (1) Makes the bot send a messsage at every  4 minutes to avoid autokick. without parameters shows the current status', 'antikick [conf] [1|0]', ['antikick 1','antikick 0','antikick'])