#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  emo-ml_plugin.py
#  coded by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

def emo_join(groupchat, nick, aff, role):
	DBPATH='dynamic/'+groupchat+'/config.cfg'
	if nick == DEFAULT_NICK:
	   if GCHCFGS[groupchat].has_key('emo'):
	           pass
	   else:
	           GCHCFGS[groupchat]['emo']=1
		   write_file(DBPATH,str(GCHCFGS[groupchat]))
	   if GCHCFGS[groupchat]['emo']==1:
				msg(ADMINS[0], u'NOTIFICATION :\nEmo Response is active in '+groupchat+'\nRead "help emo" to De-Activate it')
	   else:
				pass

        
def handler_emo(type, source, parameters):
	if type == 'public':
	  if GCHCFGS[source[1]].has_key('emo'):
		if GCHCFGS[source[1]]['emo']==1:
			if parameters == ':)':
				replies = ['nalla chiri :) ', 'ur ninte chiri r()$a yude chiri polund :$:D', ' enthu manoharamaya chiri :P :O']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-)':
				replies = ['nalla chiri :) ', 'ur ninte chiri r()$a yude chiri polund :$:D', ' enthu manoharamaya chiri :P :O']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ';)':
				replies = ['hey ivide wink idan padilla :|', 'ini nee ithu cheyyuvane thebluesteye or r()$a ninne kickum paranjekkamm :|', 'hey ithoru nalla roomanu athukond nee ithu ivde cheyyan padilla :O:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ';-)':
				replies = ['hey ivide wink idan padilla :|', 'ini nee ithu cheyyuvane thebluesteye or r()$a ninne kickum paranjekkamm :|', 'hey ithoru nalla roomanu athukond nee ithu ivde cheyyan padilla :O:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':D':
				replies = ['ninte manjapallukal ivide kanikkandattoo :D', 'inakkennodu parayamo nee enthinanu ingane chirikkunnathu:O:D', ' adyam nee poyi ninte pallu thekku :D :|', 'nee ini chiri nirthiyillenkil thebluesteye ninte pallu idichodikkum paranjekkam I-):D', ' njan karuthunnu chirichal raktham koodum :O :|', ' njan enthenkilum thamasha ninnodu paranjoo :S']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-D':
				replies = ['ninte manjapallukal ivide kanikkandattoo :D', 'inakkennodu parayamo nee enthinanu ingane chirikkunnathu:O:D', ' adyam nee poyi ninte pallu thekku :D :|', 'nee ini chiri nirthiyillenkil thebluesteye ninte pallu idichodikkum paranjekkam I-):D', ' njan karuthunnu chirichal raktham koodum :O :|', ' njan enthenkilum thamasha ninnodu paranjoo :S']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':d':
				replies = ['ninte manjapallukal ivide kanikkandattoo :D', 'inakkennodu parayamo nee enthinanu ingane chirikkunnathu:O:D', ' adyam nee poyi ninte pallu thekku :D :|', 'nee ini chiri nirthiyillenkil thebluesteye ninte pallu idichodikkum paranjekkam I-):D', ' njan karuthunnu chirichal raktham koodum :O :|', ' njan enthenkilum thamasha ninnodu paranjoo :S']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':-d':
				replies = ['ninte manjapallukal ivide kanikkandattoo :D', 'inakkennodu parayamo nee enthinanu ingane chirikkunnathu:O:D', ' adyam nee poyi ninte pallu thekku :D :|', 'nee ini chiri nirthiyillenkil thebluesteye ninte pallu idichodikkum paranjekkam I-):D', ' njan karuthunnu chirichal raktham koodum :O :|', ' njan enthenkilum thamasha ninnodu paranjoo :S']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':(':
				replies = ['ayyo ninte pennu ninne upekshichoo :|:D', 'enthanu nee sankadappettirikkunnathu chakkare :( :|', ' dhayavayi sankadappedathirikkuu (f) ;)']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-(':
				replies = ['ayyo ninte pennu ninne upekshichoo :|:D', 'enthanu nee sankadappettirikkunnathu chakkare :( :|', ' dhayavayi sankadappedathirikkuu (f) ;)']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':P':
				replies = ['nokku enikkum athupole cheyyan pattum :P:P:P:P :| :D', ':P:P:P:P:p:P enikkithu ishtamallaa:@', ' ithu kunjippillar mathre cheyyu :P :|:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-P':
				replies = ['nokku enikkum athupole cheyyan pattum :P:P:P:P :| :D', ':P:P:P:P:p:P enikkithu ishtamallaa:@', ' ithu kunjippillar mathre cheyyu :P :|:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':p':
				replies = ['nokku enikkum athupole cheyyan pattum :P:P:P:P :| :D', ':P:P:P:P:p:P enikkithu ishtamallaa:@', ' ithu kunjippillar mathre cheyyu :P :|:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-p':
				replies = ['nokku enikkum athupole cheyyan pattum :P:P:P:P :| :D', ':P:P:P:P:p:P enikkithu ishtamallaa:@', ' ithu kunjippillar mathre cheyyu :P :|:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':@':
				replies = ['njanum deshyathilanu kettoo:@:D', ':-SS aaro 1al enne polee :|', ' aha nee bhayangarananallooo :-SS :P :D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-@':
				replies = ['njanum deshyathilanu kettoo:@:D', ':-SS aaro 1al enne polee :|', ' aha nee bhayangarananallooo :-SS :P :D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':*':
				replies = ['ini melala nee ithu ivde cheythu pokalluuu :| :D', 'ithoru nalla roomanu :|']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-*':
				replies = ['ini melala nee ithu ivde cheythu pokalluuu :| :D', 'ithoru nalla roomanu :|']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':S':
				replies = ['enthukondanu nee kuzhappathilayirikkunnathu njan ninne sahayikkendathayundooo:d', 'thebluesteye ninne sahayikkendathayundo ??:-s:s:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-S':
				replies = ['enthukondanu nee kuzhappathilayirikkunnathu njan ninne sahayikkendathayundooo:d', 'thebluesteye ninne sahayikkendathayundo ??:-s:s:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':s':
				replies = ['enthukondanu nee kuzhappathilayirikkunnathu njan ninne sahayikkendathayundooo:d', 'thebluesteye ninne sahayikkendathayundo ??:-s:s:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-s':
				replies = ['enthukondanu nee kuzhappathilayirikkunnathu njan ninne sahayikkendathayundooo:d', 'thebluesteye ninne sahayikkendathayundo ??:-s:s:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '>D':
				replies = ['8[]pretham jasna  :D:-ss ', '>D>D>D>D>D>D>D:D', ' ithu ninte yadharatha mugam anoo ?:o:p:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '>d':
				replies = ['8[]pretham jasna  :D:-ss ', '>D>D>D>D>D>D>D:D', ' ithu ninte yadharatha mugam anoo ?:o:p:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(6)':
				replies = ['8[]pretham jasna  :D:-ss ', '>D>D>D>D>D>D>D:D', ' ithu ninte yadharatha mugam anoo ?:o:p:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':-&':
				replies = ['poy ninte mugam kazhukeda :D ', 'dhayavayi nee ninte mugam face wash kondu kazhukuka :d:p', ' nee hulk anoo hulkinum ithupole pacha niram anuu :o :|']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '@};-':
				replies = ['ithenikkullathano ?:$:d:d ', 'poov thannathinu valare nanniyund kettoo:):d:p']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(f)':
				replies = ['ithenikkullathano ?:$:d:d ', 'poov thannathinu valare nanniyund kettoo:):d:p']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == 'I-)':
				replies = ['u need rest go to ur bed:P:d ', 'go take a nap dear :):d:p']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-ss':
				replies = ['nee enthinanu bhayannirikkunnathu:):| ', 'enthinanu bhayannirikkunnathu :S', ' ee room  clean cheyyendathundu r()$a:D:D ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-SS':
				replies = ['nee enthinanu bhayannirikkunnathu:):| ', 'enthinanu bhayannirikkunnathu :S', ' ee room  clean cheyyendathundu r()$a:D:D ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '8[]':
				replies = ['ninte vaya adaykku chakkare:D :| :D ', 'enikku thonnunnu ninakku vishannu thudangiyennu :p:d']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == 'O:-)':
				replies = ['njan adhyamaya oru malagaye kanunnathu :D:p ', 'o fake angel here :Oo:-):d:d', ' o:-)cn u give me a wish? :(']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == 'o:-)':
				replies = ['njan adhyamaya oru malagaye kanunnathu :D:p ', 'o fake angel here :Oo:-):d:d', ' o:-)cn u give me a wish? :(']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == '<3':
				replies = ['<3:O romantic manushyar:O:S:D ', '<3 ithu pigeonsinte heart anoo :O:D:|']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(U)':
				replies = [' ithu ottikkan ninakku pasha venoo? :d:d', '(u)ninnodu ara ithu cheythathu r()$a anoo :(:(']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(u)':
				replies = [' ithu ottikkan ninakku pasha venoo? :d:d', '(u)ninnodu ara ithu cheythathu r()$a anoo :(:(']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':|':
				replies = [':| enikku silence ishtamalla :p ', 'enthu sambhavichu?:O:| ', 'enthenkilum parayu dear:)']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-|':
				replies = [':| enikku silence ishtamalla :p ', 'enthu sambhavichu?:O:| ', 'enthenkilum parayu dear:)']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(:|':
				replies = ['ee tea edukku |_|:p ', ':)ivide kidannu urangaruthu ninte kidakkiyilottu poku :P ', ' ninakku chaya venoo ??']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':#':
				replies = ['ippol njanum :-#', 'ninakkennodu parayamo enthanu karyam:-# ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-#':
				replies = ['ippol njanum :-#', 'ninakkennodu parayamo enthanu karyam:-# ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':O':
				replies = [':oenthu pattiiiiii:d:) ', ':o wht is so surprising :O:O:O ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':-O':
				replies = [':oenthu pattiiiiii:d:) ', ':o wht is so surprising :O:O:O ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':o':
				replies = [':oenthu pattiiiiii:d:) ', ':o wht is so surprising :O:O:O ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-o':
				replies = [':oenthu pattiiiiii:d:) ', ':o wht is so surprising :O:O:O ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':$':
				replies = [':$ enthu manoharamaya mugam :p:d ', 'u r so shy :$ :D', ' wht a lovely face come on give me a kiss :* :P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-$':
				replies = [':$ enthu manoharamaya mugam :p:d ', 'u r so shy :$ :D', ' wht a lovely face come on give me a kiss :* :P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)			
	elif type == 'private':
			if parameters == ':)':
				replies = ['nalla chiri :) ', 'ur ninte chiri r()$a yude chiri polund :$:D', ' enthu manoharamaya chiri :P :O']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-)':
				replies = ['nalla chiri :) ', 'ur ninte chiri r()$a yude chiri polund :$:D', ' enthu manoharamaya chiri :P :O']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ';)':
				replies = ['hey ivide wink idan padilla :|', 'ini nee ithu cheyyuvane thebluesteye or r()$a ninne kickum paranjekkamm :|', 'hey ithoru nalla roomanu athukond nee ithu ivde cheyyan padilla :O:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ';-)':
				replies = ['hey ivide wink idan padilla :|', 'ini nee ithu cheyyuvane thebluesteye or r()$a ninne kickum paranjekkamm :|', 'hey ithoru nalla roomanu athukond nee ithu ivde cheyyan padilla :O:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':D':
				replies = ['ninte manjapallukal ivide kanikkandattoo :D', 'inakkennodu parayamo nee enthinanu ingane chirikkunnathu:O:D', ' adyam nee poyi ninte pallu thekku :D :|', 'nee ini chiri nirthiyillenkil thebluesteye ninte pallu idichodikkum paranjekkam I-):D', ' njan karuthunnu chirichal raktham koodum :O :|', ' njan enthenkilum thamasha ninnodu paranjoo :S']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-D':
				replies = ['ninte manjapallukal ivide kanikkandattoo :D', 'inakkennodu parayamo nee enthinanu ingane chirikkunnathu:O:D', ' adyam nee poyi ninte pallu thekku :D :|', 'nee ini chiri nirthiyillenkil thebluesteye ninte pallu idichodikkum paranjekkam I-):D', ' njan karuthunnu chirichal raktham koodum :O :|', ' njan enthenkilum thamasha ninnodu paranjoo :S']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':d':
				replies = ['ninte manjapallukal ivide kanikkandattoo :D', 'inakkennodu parayamo nee enthinanu ingane chirikkunnathu:O:D', ' adyam nee poyi ninte pallu thekku :D :|', 'nee ini chiri nirthiyillenkil thebluesteye ninte pallu idichodikkum paranjekkam I-):D', ' njan karuthunnu chirichal raktham koodum :O :|', ' njan enthenkilum thamasha ninnodu paranjoo :S']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':-d':
				replies = ['ninte manjapallukal ivide kanikkandattoo :D', 'inakkennodu parayamo nee enthinanu ingane chirikkunnathu:O:D', ' adyam nee poyi ninte pallu thekku :D :|', 'nee ini chiri nirthiyillenkil thebluesteye ninte pallu idichodikkum paranjekkam I-):D', ' njan karuthunnu chirichal raktham koodum :O :|', ' njan enthenkilum thamasha ninnodu paranjoo :S']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':(':
				replies = ['ayyo ninte pennu ninne upekshichoo :|:D', 'enthanu nee sankadappettirikkunnathu chakkare :( :|', ' dhayavayi sankadappedathirikkuu (f) ;)']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-(':
				replies = ['ayyo ninte pennu ninne upekshichoo :|:D', 'enthanu nee sankadappettirikkunnathu chakkare :( :|', ' dhayavayi sankadappedathirikkuu (f) ;)']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':P':
				replies = ['nokku enikkum athupole cheyyan pattum :P:P:P:P :| :D', ':P:P:P:P:p:P enikkithu ishtamallaa:@', ' ithu kunjippillar mathre cheyyu :P :|:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-P':
				replies = ['nokku enikkum athupole cheyyan pattum :P:P:P:P :| :D', ':P:P:P:P:p:P enikkithu ishtamallaa:@', ' ithu kunjippillar mathre cheyyu :P :|:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':p':
				replies = ['nokku enikkum athupole cheyyan pattum :P:P:P:P :| :D', ':P:P:P:P:p:P enikkithu ishtamallaa:@', ' ithu kunjippillar mathre cheyyu :P :|:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-p':
				replies = ['nokku enikkum athupole cheyyan pattum :P:P:P:P :| :D', ':P:P:P:P:p:P enikkithu ishtamallaa:@', ' ithu kunjippillar mathre cheyyu :P :|:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':@':
				replies = ['njanum deshyathilanu kettoo:@:D', ':-SS aaro 1al enne polee :|', ' aha nee bhayangarananallooo :-SS :P :D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-@':
				replies = ['njanum deshyathilanu kettoo:@:D', ':-SS aaro 1al enne polee :|', ' aha nee bhayangarananallooo :-SS :P :D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':*':
				replies = ['ini melala nee ithu ivde cheythu pokalluuu :| :D', 'ithoru nalla roomanu :|']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-*':
				replies = ['ini melala nee ithu ivde cheythu pokalluuu :| :D', 'ithoru nalla roomanu :|']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':S':
				replies = ['enthukondanu nee kuzhappathilayirikkunnathu njan ninne sahayikkendathayundooo:d', 'thebluesteye ninne sahayikkendathayundo ??:-s:s:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-S':
				replies = ['enthukondanu nee kuzhappathilayirikkunnathu njan ninne sahayikkendathayundooo:d', 'thebluesteye ninne sahayikkendathayundo ??:-s:s:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':s':
				replies = ['enthukondanu nee kuzhappathilayirikkunnathu njan ninne sahayikkendathayundooo:d', 'thebluesteye ninne sahayikkendathayundo ??:-s:s:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-s':
				replies = ['enthukondanu nee kuzhappathilayirikkunnathu njan ninne sahayikkendathayundooo:d', 'thebluesteye ninne sahayikkendathayundo ??:-s:s:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '>D':
				replies = ['8[]pretham jasna  :D:-ss ', '>D>D>D>D>D>D>D:D', ' ithu ninte yadharatha mugam anoo ?:o:p:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '>d':
				replies = ['8[]pretham jasna  :D:-ss ', '>D>D>D>D>D>D>D:D', ' ithu ninte yadharatha mugam anoo ?:o:p:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(6)':
				replies = ['8[]pretham jasna  :D:-ss ', '>D>D>D>D>D>D>D:D', ' ithu ninte yadharatha mugam anoo ?:o:p:D']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':-&':
				replies = ['poy ninte mugam kazhukeda :D ', 'dhayavayi nee ninte mugam face wash kondu kazhukuka :d:p', ' nee hulk anoo hulkinum ithupole pacha niram anuu :o :|']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '@};-':
				replies = ['ithenikkullathano ?:$:d:d ', 'poov thannathinu valare nanniyund kettoo:):d:p']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(f)':
				replies = ['ithenikkullathano ?:$:d:d ', 'poov thannathinu valare nanniyund kettoo:):d:p']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == 'I-)':
				replies = ['u need rest go to ur bed:P:d ', 'go take a nap dear :):d:p']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-ss':
				replies = ['nee enthinanu bhayannirikkunnathu:):| ', 'enthinanu bhayannirikkunnathu :S', ' ee room  clean cheyyendathundu r()$a:D:D ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-SS':
				replies = ['nee enthinanu bhayannirikkunnathu:):| ', 'enthinanu bhayannirikkunnathu :S', ' ee room  clean cheyyendathundu r()$a:D:D ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '8[]':
				replies = ['ninte vaya adaykku chakkare:D :| :D ', 'enikku thonnunnu ninakku vishannu thudangiyennu :p:d']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == 'O:-)':
				replies = ['njan adhyamaya oru malagaye kanunnathu :D:p ', 'o fake angel here :Oo:-):d:d', ' o:-)cn u give me a wish? :(']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == 'o:-)':
				replies = ['njan adhyamaya oru malagaye kanunnathu :D:p ', 'o fake angel here :Oo:-):d:d', ' o:-)cn u give me a wish? :(']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == '<3':
				replies = ['<3:O romantic manushyar:O:S:D ', '<3 ithu pigeonsinte heart anoo :O:D:|']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(U)':
				replies = [' ithu ottikkan ninakku pasha venoo? :d:d', '(u)ninnodu ara ithu cheythathu r()$a anoo :(:(']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(u)':
				replies = [' ithu ottikkan ninakku pasha venoo? :d:d', '(u)ninnodu ara ithu cheythathu r()$a anoo :(:(']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':|':
				replies = [':| enikku silence ishtamalla :p ', 'enthu sambhavichu?:O:| ', 'enthenkilum parayu dear:)']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-|':
				replies = [':| enikku silence ishtamalla :p ', 'enthu sambhavichu?:O:| ', 'enthenkilum parayu dear:)']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == '(:|':
				replies = ['ee tea edukku |_|:p ', ':)ivide kidannu urangaruthu ninte kidakkiyilottu poku :P ', ' ninakku chaya venoo ??']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':#':
				replies = ['ippol njanum :-#', 'ninakkennodu parayamo enthanu karyam:-# ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-#':
				replies = ['ippol njanum :-#', 'ninakkennodu parayamo enthanu karyam:-# ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':O':
				replies = [':oenthu pattiiiiii:d:) ', ':o wht is so surprising :O:O:O ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)		
			elif parameters == ':-O':
				replies = [':oenthu pattiiiiii:d:) ', ':o wht is so surprising :O:O:O ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':o':
				replies = [':oenthu pattiiiiii:d:) ', ':o wht is so surprising :O:O:O ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-o':
				replies = [':oenthu pattiiiiii:d:) ', ':o wht is so surprising :O:O:O ']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':$':
				replies = [':$ enthu manoharamaya mugam :p:d ', 'u r so shy :$ :D', ' wht a lovely face come on give me a kiss :* :P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)
			elif parameters == ':-$':
				replies = [':$ enthu manoharamaya mugam :p:d ', 'u r so shy :$ :D', ' wht a lovely face come on give me a kiss :* :P']
				reply1 = random.choice(replies)      
				reply(type, source, reply1)	
				
				
def handler_emo_onoff(type, source, parameters):
	if not source[1] in GROUPCHATS:
		reply(type, source, u'This command only possible in the conference')
		return
	if parameters:
		try:
			parameters=int(parameters.strip())
		except:
			reply(type,source,u'read "help emo"')
			return		
		DBPATH='dynamic/'+source[1]+'/config.cfg'
		if parameters==1:
			if GCHCFGS[source[1]]['emo']==1:
				reply(type,source,u'Emo Response Already Enabled !')
				return
			else:
				GCHCFGS[source[1]]['emo']=1
				reply(type,source,u'Emo Response Enabled !')
				return
		else:
			GCHCFGS[source[1]]['emo']=0
			reply(type,source,u'Emo Response Disabled !')
		write_file(DBPATH,str(GCHCFGS[source[1]]))
	else:
		ison=GCHCFGS[source[1]]['emo']
		if ison==1:
			reply(type,source,u'Emo Response is Enabled here !')
		else:
			reply(type,source,u'Emo Response is Disabled here !')


register_join_handler(emo_join)
register_message_handler(handler_emo)
register_command_handler(handler_emo_onoff, 'emo', ['admin','muc','all'], 100, 'Off (0) On (1) activate or de-activate Emo response, without parameter shows current status', 'emo [conf] [1|0]', ['emo 1','emo 0','emo'])