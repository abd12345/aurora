#--===auroraplugin===--
# -*- coding: utf-8 -*-
#  aurora plugin
#  roster_plugin.py
#  edited by kf (kforkingfisher@/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########


def roster_sub(type,source,parameters):
        if parameters:
                if not parameters.count('@') or not parameters.count('.'):
                        reply(type,source,u'read the help command!')
                        return
                ROSTER = JCON.getRoster()
                ROSTER.Subscribe(parameters)
                reply(type,source,u'subscribed!')

def roster_unsub(type,source,parameters):
        if parameters:
                if  not parameters.count('@') or not parameters.count('.'):
                        reply(type,source,u'read the help command!')
                        return
                ROSTER = JCON.getRoster()
                ROSTER.Unsubscribe(parameters)
                ROSTER.delItem(parameters)
                reply(type,source,u'unsubscribed!')

def roster_show(type,source,parameters):
        ROSTER = JCON.getRoster()
        s=''
        rep = ROSTER.getItems()
        for x in rep:
                s+=x+' : '+unicode(ROSTER.getShow(x))+'\n'
        reply(type,source, s)

def handler_roster_onoff(type, source, parameters):
	if parameters:
		try:
			parameters=int(parameters.strip())
		except:
			reply(type,source,u'Read "help roster"')
			return
		if parameters==1:
			if STATUSES['roster'] == 1:
				reply(type,source,u'Auto-Subscribe is Already Enabled')
			else:
				STATUSES['roster'] = 1
				reply(type,source,u'Auto-Subscribe Enabled')
		elif parameters==0:
			if STATUSES['roster'] == 0:
				reply(type,source,u'Auto-Subscribe is Already Disabled')
			else:
				STATUSES['roster'] = 0
				reply(type,source,u'Auto-Subscribe Disabled')
		else:
			reply(type,source,u'Read "help roster"')
		write_file(GROUPCHAT_STATUS_CACHE_FILE,str(STATUSES))
	else:
		ison=STATUSES['roster']
		if ison==1:
			reply(type,source,u'Auto-Subscribe is Enabled')
		else:
			reply(type,source,u'Auto-Subscribe is Disabled')

register_command_handler(handler_roster_onoff, 'roster', ['admin','muc','all'], 30, 'Off (0) on (1) auto subscribe users on requesting subscription.', 'roster [1/0]', ['roster 1','roster'])
register_command_handler(roster_show, 'roster_show', ['superadmin','all'], 100, 'Show contacts on bot roster.', 'roster_show', ['roster_show'])          
register_command_handler(roster_sub, 'roster_add', ['superadmin','all'], 100, 'Subscribe a contact on bot roster.', 'roster_add <jid>', ['roster_add guy@server.tld'])
register_command_handler(roster_unsub, 'roster_del', ['superadmin','all'], 100, 'Delete a contact on bot roster.', 'roster_del <jid>', ['roster_del guy@server.tld'])
