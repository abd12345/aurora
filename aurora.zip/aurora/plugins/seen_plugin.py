#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  seen_plugin.py
#  coded by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################


SEENS={}

def seen_handler_leave(groupchat, nick, reason, code):
#	try:
		rcode=''
		if groupchat in GROUPCHATS:
			if code=='301':
				rcode=u'Banned'
			elif code=='307':
				rcode=u'Kicked'
			elif code=='321' or code=='322':
				rcode=u'conference was closed for visitors !!'
				
			if rcode:
				if reason:
					reason=rcode+' ['+reason+']'
				else:
					reason=rcode
					
			ltime=int(time.time())
			jid=get_true_jid(groupchat+'/'+nick)
			
			if not SEENS.has_key(groupchat):
				SEENS[groupchat]={}
			SEENS[groupchat][nick]=[ltime,reason,jid]
			
			
#   except:
#       pass
 
def seen_handler_write(groupchat):
	if check_file(groupchat,'seen.txt'):
		write_file('dynamic/'+groupchat+'/seen.txt', str(SEENS[groupchat]))
		time.sleep(0.02)

def seen_handler_loop():
	while 1:
		try:
			time.sleep(800)
			for groupchat in SEENS.keys():
				seen_handler_write(groupchat)
		except:
			pass

def seen_handler_load(groupchat):
	if check_file(groupchat,'seen.txt'):
		SEENS[groupchat] = eval(read_file('dynamic/'+groupchat+'/seen.txt'))

			
def handler_seen_call(type, source, parameters):
	groupchat=source[1]
	if type == 'public':
		if not parameters:
			reply(type, source, u'Seen Who ?.')
			return	

		if parameters==source[2] or parameters==get_true_jid(source[0]):
			reply(type, source, u'Look at yourself in the mirror! ;-)')
			return		

		if GROUPCHATS[groupchat].has_key(parameters):
			if GROUPCHATS[groupchat][parameters]['ishere']==1:
				reply(type, source, u''+parameters+' is still in the Conference...')
				return
			
		if SEENS[groupchat].has_key(parameters):
			lasttime=int(time.time()) - SEENS[groupchat][parameters][0]
			reason=SEENS[groupchat][parameters][1]
		
			if reason:
				rep = parameters+u' was here '+timeElapsed(lasttime)+u' before ('+reason+u')'
			else:	
				rep = parameters+u' was here '+timeElapsed(lasttime)+u' before'		
			reply(type, source, rep)
		else:	
			reply(type, source, u'I had never seen '+parameters)
			return
    	elif type == 'private':
		reply(type, source, u'Only works in conference !!')

		
register_command_handler(handler_seen_call, 'seen',['all'], 0, 'When the user was last here.', 'seen <nick/jid>', ['seen k.i.n.g.f.i.s.h.e.r','seen k.i.n.g.f.i.s.h.e.r@nimbuzz.com'])


register_leave_handler(seen_handler_leave)

register_stage0_init(seen_handler_loop)

register_stage1_init(seen_handler_load)



def handler_beeninmuc(type, source, parameters):
	groupchat=source[1]

	if not GROUPCHATS.has_key(groupchat):
		reply(type, source, u'Only works in conference !!')
		return
		
	seen_handler_write(groupchat)
	
	if not SEENS.has_key(groupchat):
		reply(type, source, u'unknown error.')
		return
	
	limit=86400
	ms=''
	ss=''
	
	if parameters:
		try:
			limit=int(parameters.strip()) * 3600
			if limit <= 0:
				reply(type, source, u'I look to the future:-)')
				return				
		except:
			reply(type, source, u'And the number ?')
			return			
	for key in SEENS[groupchat]:
		try:
			if GROUPCHATS[groupchat].has_key(key) and GROUPCHATS[groupchat][key]['ishere']==1:
				continue
		except:
			continue
		if time.time() - SEENS[groupchat][key][0] <= limit:
			ms += key + ', '
			
	if not ms:
			reply(type, source, u'I have not seen anybody, all here :-)')
			return
	limit = limit / 3600
	if limit==2 or limit==24 or limit==23 or limit==22 or limit==34 or limit==33 or limit==22:
		ss=str(limit) + u' hours'
	elif limit==1 or limit==21 or limit==31 or limit==41 or limit==51:
		ss=str(limit) + u' hours'
	else:
		ss=str(limit) + u' hours'
			
	reply(type, source, u'over the last '+ ss +u' I saw the following users :\n' + ms[:-2] + u'.\nAnd the others are still here! :-)')



register_command_handler(handler_beeninmuc, 'whowas', ['muc','all','info'], 0, 'Shows who was in the last day of the conference, or if the options n - then for n hours.\nDisplays who are not in the conference at the time of enquiry.', 'whowas <# hours>', ['whowas','whowas 12'])

