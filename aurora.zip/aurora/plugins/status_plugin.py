#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  status_plugin.py
#  created by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

def handler_botstatus(type, source, parameters):
	if parameters:
		args,show,status=parameters.split(' ',1),'',''
		if args[0] in ['online','chat','xa','away','dnd','busy']:
			show=args[0]
		else:
			show=None
			status=parameters
		if not status:
			try:
				status=args[1]
			except:
				status=None
		change_bot_status(status,show)
		if show == None:
			reply('private', source, 'Error - "'+args[0]+'" is Not a valid Status ! \nDefault Status is used !')
		elif status == None:
			reply('private', source, 'Error - "Status message absent !".\nDefault Status Message is used !')
		else:
			reply('private',source, u'I am now "'+show+'". \n"'+status+'".')
	else:
		reply('private',source, u'Read "help .bs"')

def handler_botautoaway_onoff(type, source, parameters):
	if parameters:
		try:
			parameters=int(parameters.strip())
		except:
			reply(type,source,u'Read "help autoaway"')
			return
		if parameters==1:
			if LOCAL_CONFIG['autoaway'] == 1:
				reply(type,source,u'Auto-Away is Already Enabled')
			else:
				LOCAL_CONFIG['autoaway'] = 1
				reply(type,source,u'Auto-Away Enabled')
		elif parameters==0:
			if LOCAL_CONFIG['autoaway'] == 0:
				reply(type,source,u'Auto-Away is Already Disabled')
			else:
				LOCAL_CONFIG['autoaway'] = 0
				reply(type,source,u'Auto-Away Disabled')
		else:
			reply(type,source,u'Read "help autoaway"')
		write_file(GROUPCHAT_STATUS_CACHE_FILE,str(LOCAL_CONFIG))
	else:
		ison=LOCAL_CONFIG['autoaway']
		if ison==1:
			reply(type,source,u'Auto-Away is Enabled')
		else:
			reply(type,source,u'Auto-Away is Disabled')

def handler_user_status(type, source, parameters):
	if parameters:
		if GROUPCHATS.has_key(source[1]) and GROUPCHATS[source[1]].has_key(parameters):
			stmsg=GROUPCHATS[source[1]][parameters]['stmsg']
			status=GROUPCHATS[source[1]][parameters]['status']
			if stmsg:
				reply(type,source, parameters+u' now '+status+u' ('+stmsg+u')')
			else:
				reply(type,source, parameters+u' now '+status)
		else:
			reply(type,source, u'was he here? :-O')
	else:
		if GROUPCHATS.has_key(source[1]) and GROUPCHATS[source[1]].has_key(source[2]):
			stmsg=GROUPCHATS[source[1]][source[2]]['stmsg']
			status=GROUPCHATS[source[1]][source[2]]['status']
			if stmsg:
				reply(type,source, u'you now '+status+u' ('+stmsg+u')')
			else:
				reply(type,source, u'you now '+status)

    
register_command_handler(handler_botstatus, '.bs', ['mod','admin','all'], 100, 'Changes bot status and PM.', '.bs <status> <message>', ['.bs dnd aurora bot by kf'])
register_command_handler(handler_botautoaway_onoff, 'autoaway', ['admin','muc','all'], 30, 'Off (0) on (1) auto-away due to abscence of commands within 10 minutes, without an option it will show current status.', 'autoaway [1/0]', ['autoaway 1','autoaway'])
register_command_handler(handler_user_status, 'status', ['info','muc','all'], 0, 'Shows status and status report (if available) of certain user or itself.', 'status <user>', ['status', 'status guy'])