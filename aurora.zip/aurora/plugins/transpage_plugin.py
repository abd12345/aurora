#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  transpage_plugin.py
#  coded by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################

Langs = {'en': u'English', 'ja': u'japanese', 'ru': u'russian', 'auto': u'Determine language', 'sq': u'Albanian', 'ar': u'Arabic', 'af': u'Afrikaans', 'be': u'Belarusian', 'bg': u'Bulgarian', 'cy': u'Welsh', 'hu': u'Hungarian', 'vi': u'Vietnamese', 'gl': u'Galician', 'nl': u'Dutch', 'el': u'Greek', 'da': u'Danish', 'iw': u'Hebrew', 'yi': u'Yiddish', 'id': u'Indonesian', 'ga': u'Irish', 'is': u'Icelandic', 'es': u'Spanish', 'it': u'Italian', 'ca': u'Catalan', 'zh-CN': u'Chinese', 'ko': u'Korean', 'lv': u'Latvian', 'lt': u'Lithuanian', 'mk': u'Macedonian', 'ms': u'Malay', 'mt': u'Maltese', 'de': u'German', 'no': u'Norwegian', 'fa': u'Persian', 'pl': u'Polish', 'pt': u'Portuguese', 'ro': u'Romanian', 'sr': u'Serbian', 'sk': u'Slovak', 'sl': u'Slovenian','sw': u'Swahili', 'tl': u'Filipino', 'th': u'Thai', 'tr': u'Turkish', 'uk': u'Ukrainian', 'fi': u'Finnish', 'fr': u'French', 'hi': u'Hindi', 'hr': u'Croatian', 'cs': u'Czech', 'sv': u'Swedish', 'et': u'Estonian'}



def handler_transpage_(type, source, parameters):
    if parameters:
		raw = string.split(parameters, ' ', 2)
                if  not parameters.count(':') and (len(raw)<2) or (len(raw)>2):
                        reply(type, source,u'Read private for help !!')
			reply('private', source,u'Example - "Transpage http://www.yandex.ru/ hi" \nthis will translate the page into Hindi !! \nType "Translang" to see avalable languages !')
                        return
		else:
                	parameters=parameters.strip().lower()
                	parameters=parameters.split(' ')
                	parameters1=parameters[0]
                	parameters2=parameters[1]
                        reply(type, source,u'Send to private !!')
			reply('private', source, u'http://translate.google.co.in/translate?hl=en&sl=auto&tl='+parameters[1]+'&u='+parameters[0])
                	
    else:			
			reply(type, source,u'Read private for help !!')
			reply('private', source, u'Provide "WEBPAGE URL" to translate WEB PAGE ! \nExample - "Transpage http://www.yandex.ru/ hi" \nThis will translate the page into Hindi !! \nType "Translang" to see avalable languages !!')

def handler_transpage_lang_(type, source, parameters):
              answer = u"Available in These Languages:\n"
              for a, b in enumerate(sorted([x + u" — " + y for x, y in Langs.iteritems()])):
                      answer += u"%i. %s " % (a + 1, b)
	      reply(type, source,u'send to private !!')
	      reply('private', source, answer.encode("utf-8"))
	      reply('private', source, u'transpage <URL> <target language> \nexample - transpage http://www.yandex.ru/ hi \nsend "help transpage" for help')

register_command_handler(handler_transpage_, 'transpage', ['new'], 0, 'translate the WEBPAGE to target language.', 'transpage <URL> <target language>', ['transpage http://www.yandex.ru/ hi'])
register_command_handler(handler_transpage_lang_, 'translang', ['new'], 0, 'displays the avalalable tranlatable languages', 'translang', ['translang'])