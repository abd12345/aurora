#--===auroraplugin===--
#  -*- coding: utf-8 -*-
#  aurora plugin
#  unmember_plugin.py
#  edited by kf (kforkingfisher@gmail/nimbuzz.com)
#############################################
###########    ##    #####         ##########
############  ###  #######  #####  ##########
############  ##  ########  #################
############  #  #########  #################
############    ##########  #### ############
############   ###########       ############
############    ##########  #### ############
############  #  #########  #################
############  ##   #######  #################
############  ###   ######  #################
###########    ##     ###    ################
#############################################
###########KFORKINGFISHER@GMAIL.COM##########
##########KFORKINGFISHER@NIMBUZZ.COM#########
#############################################


def handler_unmemberaf(type, source, parameters):
   count= parameters.split()[1]
   how = parameters.split()[2]
   jid = parameters.split()[0]
   iq = xmpp.Iq('set')
   iq.setID('ulti_member')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#member')
   for i in range(int(count), int(how)):
      count= int(count) + 1
      
      
      query.addChild('item', {'jid':jid+str(count)+'@nimbuzz.com', 'affiliation':'none'})
   iq.addChild(node=query)
   JCON.SendAndCallForResponse(iq, handler_unmember_answ, {'type': type, 'source': source})







def handler_unmemberbe(type, source, parameters):
   count= parameters.split()[1]
   how = parameters.split()[2]
   jid = parameters.split()[0]
   iq = xmpp.Iq('set')
   iq.setID('ulti_member')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#member')
   for i in range(int(count), int(how)):
      count= int(count) + 1
      
      
      query.addChild('item', {'jid':str(count)+jid+'@nimbuzz.com', 'affiliation':'none'})
   iq.addChild(node=query)
   JCON.SendAndCallForResponse(iq, handler_unmember_answ, {'type': type, 'source': source})





def handler_unmemberbt(type, source, parameters):
   count= parameters.split()[1]
   how = parameters.split()[2]
   jid = parameters.split()[0]
   iq = xmpp.Iq('set')
   iq.setID('ulti_member')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#member')
   for i in range(int(count), int(how)):
      count= int(count) + 1
      
      
      query.addChild('item', {'jid':jid+'-'+str(count)+'-@nimbuzz.com', 'affiliation':'none'})
   iq.addChild(node=query)
   JCON.SendAndCallForResponse(iq, handler_unmember_answ, {'type': type, 'source': source})

def handler_unmemberbt1(type, source, parameters):
   count= parameters.split()[1]
   how = parameters.split()[2]
   jid = parameters.split()[0]
   iq = xmpp.Iq('set')
   iq.setID('ulti_member')
   iq.setTo(source[1])
   query = xmpp.Node('query')
   query.setNamespace('http://jabber.org/protocol/muc#member')
   for i in range(int(count), int(how)):
      count= int(count) + 1
      
      
      query.addChild('item', {'jid':jid+str(count)+jid+'@nimbuzz.com', 'affiliation':'none'})
   iq.addChild(node=query)
   JCON.SendAndCallForResponse(iq, handler_unmember_answ, {'type': type, 'source': source})

def handler_unmember_answ(coze, res, type, source):
   if res:
      if res.getType() == 'result':
         reply(type, source, u'DONE;-);).')
      else:
         
         reply(type, source, u'Error. Try again, or unmember less quantity.')





register_command_handler(handler_unmemberaf, 'unmember-', ['info','muc','all'], 20, 'unmember serial IDs with number after', 'unmember-', ['unmember-'])
register_command_handler(handler_unmemberbe, '-unmember', ['info','muc','all'], 20, 'unmember serial IDs with number before', '-unmember', ['-unmember'])
register_command_handler(handler_unmemberbt, '-unmember-', ['info','muc','all'], 20, 'unmember serial IDs with number between --', '-unmember-', ['-unmember-'])
register_command_handler(handler_unmemberbt1, '-un-member-', ['info','muc','all'], 20, 'unmember serial IDs with number between same two words', '-un-member-', ['-un-member-'])
